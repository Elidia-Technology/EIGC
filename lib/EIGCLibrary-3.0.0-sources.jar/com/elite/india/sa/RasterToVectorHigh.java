/*
 * The MIT License
 * Copyright (c) 2024-2025 Elite India
 *
 * Author: Saleem Ahmad
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.elite.india.sa;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;

/**
 * The RasterToVectorHigh class provides functionality to convert raster images to vector formats (SVG, EPS)
 * and also to TIFF format. It includes methods to scale images and reduce color depth for optimization.
 * 
 * <p>Usage example:</p>
 * <pre>
 * {@code
 * try {
 *     String inputImage = "/path/to/input/image.png";
 *     String outputSVG = "/path/to/output/image.svg";
 *     String outputEPS = "/path/to/output/image.eps";
 *     String outputTIFF = "/path/to/output/image.tiff";
 * 
 *     double scaleFactor = 0.5; // Reduce image size to 50%
 *     int colorReductionLevel = 64; // Reduce colors (higher = more compression)
 * 
 *     RasterToVectorHigh converter = new RasterToVectorHigh(inputImage, outputSVG, scaleFactor, colorReductionLevel);
 *     converter.convertToSVG();
 * 
 *     converter = new RasterToVectorHigh(inputImage, outputEPS, scaleFactor, colorReductionLevel);
 *     converter.convertToEPS();
 * 
 *     converter = new RasterToVectorHigh(inputImage, outputTIFF, scaleFactor, colorReductionLevel);
 *     converter.convertToTIFF();
 * } catch (Exception e) {
 *     e.printStackTrace();
 * }
 * }
 * </pre>
 * 
 * <p>Methods:</p>
 * <ul>
 * <li>{@link #RasterToVectorHigh(String, String, double, int)} - Constructs a RasterToVectorHigh object with the specified parameters.</li>
 * <li>{@link #convertToSVG()} - Converts the raster image to an SVG format and saves it to a file.</li>
 * <li>{@link #convertToEPS()} - Converts the raster image to an EPS format and saves it to a file.</li>
 * <li>{@link #convertToTIFF()} - Converts the raster image to a TIFF format and saves it to a file.</li>
 * <li>{@link #scaleImage(BufferedImage, double)} - Scales the given BufferedImage by the specified scale factor.</li>
 * <li>{@link #reduceColors(BufferedImage, int)} - Reduces the number of colors in the given BufferedImage by decreasing the color depth.</li>
 * <li>{@link #generateOptimizedSVG()} - Generates an optimized SVG representation of the image.</li>
 * <li>{@link #generateOptimizedEPS()} - Generates an optimized EPS representation of the image.</li>
 * <li>{@link #saveSVG(String)} - Saves the provided SVG data to a file specified by the outputFilePath.</li>
 * <li>{@link #saveEPS(String)} - Saves the provided EPS data to a file specified by the outputFilePath.</li>
 * <li>{@link #saveTIFF(BufferedImage, String)} - Saves a BufferedImage as a TIFF file to the specified output file path.</li>
 * </ul>
 */
public class RasterToVectorHigh {

    private BufferedImage image;
    private String outputFilePath;
    private double scaleFactor;  // Reduce image size
    private int colorReductionLevel; // Reduce colors

    /**
     * Constructs a RasterToVectorHigh object with the specified parameters.
     *
     * @param inputImagePath the path to the input image file
     * @param outputFilePath the path to the output file
     * @param scaleFactor the factor by which to scale the image; if less than 1.0, the image will be scaled down
     * @param colorReductionLevel the level of color reduction to apply; if greater than 0, the image colors will be reduced
     * @throws IOException if an error occurs during reading the input image file
     */
    public RasterToVectorHigh(String inputImagePath, String outputFilePath, double scaleFactor, int colorReductionLevel) throws IOException {
        this.image = ImageIO.read(new File(inputImagePath));
        this.outputFilePath = outputFilePath;
        this.scaleFactor = scaleFactor;
        this.colorReductionLevel = colorReductionLevel;

        if (scaleFactor < 1.0) {
            this.image = scaleImage(image, scaleFactor);
        }

        if (colorReductionLevel > 0) {
            this.image = reduceColors(image, colorReductionLevel);
        }
    }

    /**
     * Converts the raster image to an SVG format.
     * This method generates an optimized SVG representation of the raster image
     * and saves it to a file.
     *
     * @throws IOException if an I/O error occurs during the SVG generation or saving process.
     */
    public void convertToSVG() throws IOException {
        String svgData = generateOptimizedSVG();
        saveSVG(svgData);
    }

    /**
     * Converts the current raster image to an EPS (Encapsulated PostScript) format.
     * This method generates an optimized EPS representation of the image and saves it to a file.
     *
     * @throws IOException if an I/O error occurs during the conversion or saving process.
     */
    public void convertToEPS() throws IOException {
        String epsData = generateOptimizedEPS();
        saveEPS(epsData);
    }

    /**
     * Converts the current image to a TIFF format and saves it to the specified output file path.
     *
     * @throws IOException if an error occurs during the saving process.
     */
    public void convertToTIFF() throws IOException {
        saveTIFF(image, outputFilePath);
    }

    /**
     * Scales the given BufferedImage by the specified scale factor.
     *
     * @param img the BufferedImage to be scaled
     * @param scale the scale factor to apply to the image dimensions
     * @return a new BufferedImage that is scaled to the specified dimensions
     */
    private BufferedImage scaleImage(BufferedImage img, double scale) {
        int newWidth = (int) (img.getWidth() * scale);
        int newHeight = (int) (img.getHeight() * scale);
        Image scaled = img.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        BufferedImage newImg = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = newImg.createGraphics();
        g.drawImage(scaled, 0, 0, null);
        g.dispose();
        return newImg;
    }

    /**
     * Reduces the number of colors in the given BufferedImage by decreasing the color depth.
     *
     * @param img the original BufferedImage to be processed
     * @param levels the number of levels to reduce each color channel to
     * @return a new BufferedImage with reduced color depth
     */
    private BufferedImage reduceColors(BufferedImage img, int levels) {
        int width = img.getWidth();
        int height = img.getHeight();
        BufferedImage reducedImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int pixel = img.getRGB(x, y);
                Color color = new Color(pixel, true);

                // Reduce color depth
                int red = (color.getRed() / levels) * levels;
                int green = (color.getGreen() / levels) * levels;
                int blue = (color.getBlue() / levels) * levels;

                Color newColor = new Color(red, green, blue, color.getAlpha());
                reducedImg.setRGB(x, y, newColor.getRGB());
            }
        }
        return reducedImg;
    }

    /**
     * Generates an optimized SVG representation of the image.
     * The method scans the image pixel by pixel and creates SVG rectangles
     * for continuous blocks of the same color to minimize the number of SVG elements.
     *
     * @return A string containing the SVG representation of the image.
     */
    private String generateOptimizedSVG() {
        int width = image.getWidth();
        int height = image.getHeight();
        StringBuilder svg = new StringBuilder();
        svg.append("<svg xmlns='http://www.w3.org/2000/svg' width='").append(width)
                .append("' height='").append(height).append("'>\n");

        boolean[][] visited = new boolean[height][width];

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                if (visited[y][x]) {
                    continue;
                }

                int pixel = image.getRGB(x, y);
                Color color = new Color(pixel, true);

                if (color.getAlpha() > 0) {
                    String hexColor = String.format("#%02x%02x%02x", color.getRed(), color.getGreen(), color.getBlue());

                    // Find width of continuous block with same color
                    int w = 1;
                    while (x + w < width && image.getRGB(x + w, y) == pixel) {
                        visited[y][x + w] = true;
                        w++;
                    }

                    svg.append("<rect x='").append(x).append("' y='").append(y)
                            .append("' width='").append(w).append("' height='1' fill='").append(hexColor).append("' />\n");
                }
                visited[y][x] = true;
            }
        }
        svg.append("</svg>");
        return svg.toString();
    }

    /**
     * Generates an optimized Encapsulated PostScript (EPS) representation of the image.
     * The method processes the image to create a string in EPS format, which includes
     * the EPS header, bounding box, and pixel data. It optimizes the output by grouping
     * continuous blocks of the same color and drawing them as filled rectangles.
     *
     * @return A string containing the EPS representation of the image.
     */
    private String generateOptimizedEPS() {
        int width = image.getWidth();
        int height = image.getHeight();
        StringBuilder eps = new StringBuilder();

        // EPS header (including bounding box)
        eps.append("%!PS-Adobe-3.0 EPSF-3.0\n");
        eps.append("%%BoundingBox: 0 0 ").append(width).append(" ").append(height).append("\n");

        eps.append("gsave\n");

        // Initialize a boolean array to track visited pixels
        boolean[][] visited = new boolean[height][width];

        // Loop through the image and draw the pixel blocks
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                if (visited[y][x]) {
                    continue;
                }

                // Get the color of the current pixel
                int pixel = image.getRGB(x, y);
                Color color = new Color(pixel, true);

                // Skip fully transparent pixels
                if (color.getAlpha() == 0) {
                    continue;
                }

                // Find the width of continuous blocks of the same color
                int blockWidth = 1;
                while (x + blockWidth < width && image.getRGB(x + blockWidth, y) == pixel && !visited[y][x + blockWidth]) {
                    blockWidth++;
                }

                // Mark the pixels as visited
                for (int i = 0; i < blockWidth; i++) {
                    visited[y][x + i] = true;
                }

                // Set color (convert to RGB for EPS)
                String hexColor = String.format("#%02x%02x%02x", color.getRed(), color.getGreen(), color.getBlue());
                eps.append(hexColor).append(" setrgbcolor\n");

                // If the block width is large enough, draw it as a filled rectangle
                if (blockWidth > 1) {
                    eps.append(x).append(" ").append(height - y).append(" moveto\n");
                    eps.append(blockWidth).append(" 0 rlineto\n");
                    eps.append("0 ").append(-1 * blockWidth).append(" rlineto\n");
                    eps.append(-1 * blockWidth).append(" 0 rlineto\n");
                    eps.append("closepath\n");
                    eps.append("fill\n");
                } else {
                    // Otherwise, draw a single point (or tiny block)
                    eps.append(x).append(" ").append(height - y).append(" moveto\n");
                    eps.append("1 1 rlineto\n");
                    eps.append("fill\n");
                }
            }
        }

        eps.append("grestore\n");

        return eps.toString();
    }

    /**
     * Saves the provided SVG data to a file specified by the outputFilePath.
     *
     * @param svgData The SVG data to be saved as a string.
     * @throws IOException If an I/O error occurs while writing the file.
     */
    private void saveSVG(String svgData) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
            writer.write(svgData);
        }
        System.out.println("SVG saved: " + outputFilePath);
    }

    /**
     * Saves the given EPS (Encapsulated PostScript) data to a file specified by the outputFilePath.
     *
     * @param epsData The EPS data to be saved.
     * @throws IOException If an I/O error occurs while writing the file.
     */
    private void saveEPS(String epsData) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
            writer.write(epsData);
        }
        System.out.println("EPS saved: " + outputFilePath);
    }

    /**
     * Saves a BufferedImage as a TIFF file to the specified output file path.
     *
     * @param image the BufferedImage to be saved
     * @param outputFilePath the path where the TIFF file will be saved
     * @throws IOException if an error occurs during writing the file
     */
    private void saveTIFF(BufferedImage image, String outputFilePath) throws IOException {
        File outputFile = new File(outputFilePath);
        ImageIO.write(image, "TIFF", outputFile);
        System.out.println("TIFF saved: " + outputFilePath);
    }

    public static void main(String[] args) {
        try {
            String inputImage = "/home/saleem/Pictures/spiderman.png";
            String outputSVG = "/home/saleem/Pictures/spiderman4.svg";
            String outputEPS = "/home/saleem/Pictures/spiderman4.eps";//eps is not working
            String outputTIFF = "/home/saleem/Pictures/spiderman4.tiff";

            double scaleFactor = 0.5; // Reduce image size to 50%
            int colorReductionLevel = 64; // Reduce colors (higher = more compression)

            RasterToVectorHigh converter = new RasterToVectorHigh(inputImage, outputSVG, scaleFactor, colorReductionLevel);
            converter.convertToSVG();
            converter = new RasterToVectorHigh(inputImage, outputEPS, scaleFactor, colorReductionLevel);
//            converter.convertToEPS();
            converter.convertToEPS();

            converter = new RasterToVectorHigh(inputImage, outputTIFF, scaleFactor, colorReductionLevel);
            converter.convertToTIFF();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
