/*
 * The MIT License
 * Copyright (c) 2024-2025 Elite India
 *
 * Author: Saleem Ahmad
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.elite.india.sa.thirdparty;

/**
 *
 * @author saleem
 */
import java.io.PrintStream;
import java.util.*;
import java.util.concurrent.*;

public class InkscapeCommandCreator {

    private String version = "new"; // or "old" depending on your use case    
    private static final int MAX_CONCURRENT_TASKS = 5;
    private static final ExecutorService executorService = Executors.newFixedThreadPool(MAX_CONCURRENT_TASKS);

    public InkscapeCommandCreator() {
        // ✅ Redirect Java Console Output to Node.js Console
        PrintStream consoleOut = System.out;
        PrintStream consoleErr = System.err;

        System.setOut(new PrintStream(System.out) {
            public void println(String s) {
                super.println("[GTGS-LOG] " + s);
            }
        });

        System.setErr(new PrintStream(System.err) {
            public void println(String s) {
                super.println("[CORE-ERROR] " + s);
            }
        });

        System.out.println("✅ InkscapeCommandCreator Class Initialized!");
    }

    /**
     * Creates an Inkscape command based on the provided options.
     *
     * @param options The options to configure the Inkscape command.
     * @return An InkscapeCommand object containing the command arguments, the
     * command string, and the input file path.
     */
    public InkscapeCommand createInkscapeCommand(InkscapeOptions options) {
        this.version = options.getVersion();
        String inputFilePath = options.getInputFilePath();
        String outputFilePath = options.getOutputFilePath().replaceAll("\\.[^/.]+$", "");
        String exportType = options.getExportType();

        List<String> args = new ArrayList<>();
        StringBuilder command = new StringBuilder();

        // Ensure Inkscape is explicitly added as the first argument
        args.add("inkscape");
        command.append("inkscape ");

        if (this.version.equals("old")) {
            args.add("-f");
            args.add(inputFilePath);
            command.append("-f ").append(inputFilePath);
        } else {
            args.add(inputFilePath);
            command.append(inputFilePath);
        }

        if (this.version.equals("old")) {
            switch (exportType) {
                case "pdf":
                    args.add("-A");
                    args.add(outputFilePath + ".pdf");
                    command.append(" -A ").append(outputFilePath).append(".pdf");
                    break;
                case "png":
                    args.add("-e");
                    args.add(outputFilePath + ".png");
                    command.append(" -e ").append(outputFilePath).append(".png");
                    break;
                case "eps":
                    args.add("-E");
                    args.add(outputFilePath + ".eps");
                    command.append(" -E ").append(outputFilePath).append(".eps");
                    break;
                case "svg":
                    args.add("-l");
                    args.add(outputFilePath + ".svg");
                    command.append(" -l ").append(outputFilePath).append(".svg");
                    break;
                case "tiff":
                    args.add("-t");
                    args.add(outputFilePath + ".tiff");
                    command.append(" -t ").append(outputFilePath).append(".tiff");
                    break;
                case "jpg":
                    args.add("-j");
                    args.add(outputFilePath + ".jpg");
                    command.append(" -j ").append(outputFilePath).append(".jpg");
                    break;
            }
        } else {
            args.add("--export-type=" + exportType);
            args.add("--export-filename=" + outputFilePath + "." + exportType);
            command.append(" --export-type=").append(exportType);
            command.append(" --export-filename=").append(outputFilePath).append(".").append(exportType);
        }

        // Add optional parameters if set
        if (options.getDpi() != null) {
            args.add("--export-dpi=" + options.getDpi());
            command.append(" --export-dpi=").append(options.getDpi());
        }
        if (options.getWidth() != null) {
            args.add("--export-width=" + options.getWidth());
            command.append(" --export-width=").append(options.getWidth());
        }
        if (options.getHeight() != null) {
            args.add("--export-height=" + options.getHeight());
            command.append(" --export-height=").append(options.getHeight());
        }
        if (options.getArea() != null) {
            args.add("--export-area-" + options.getArea());
            command.append(" --export-area-").append(options.getArea());
        }
        if (options.getMargin() != null) {
            args.add("--export-margin=" + options.getMargin());
            command.append(" --export-margin=").append(options.getMargin());
        }
        if (options.getBackground() != null) {
            args.add("--export-background=" + options.getBackground());
            command.append(" --export-background=").append(options.getBackground());
        }
        if (options.getBackgroundOpacity() != null) {
            args.add("--export-background-opacity=" + options.getBackgroundOpacity());
            command.append(" --export-background-opacity=").append(options.getBackgroundOpacity());
        }
        if (options.getExportId() != null) {
            args.add("--export-id=" + options.getExportId());
            command.append(" --export-id=").append(options.getExportId());
        }
        if (options.isExportIdOnly()) {
            args.add("--export-id-only");
            command.append(" --export-id-only");
        }
        if (options.isExportPlainSvg()) {
            args.add("--export-plain-svg");
            command.append(" --export-plain-svg");
        }
        if (options.getAdditionalOptions() != null) {
            args.addAll(options.getAdditionalOptions());
            for (String opt : options.getAdditionalOptions()) {
                command.append(" ").append(opt);
            }
        }

        return new InkscapeCommand(args, command.toString(), inputFilePath);
    }

    /**
     * Submits the given InkscapeCommand for asynchronous execution.
     *
     * @param command the InkscapeCommand to be executed asynchronously
     */
    public void executeCommandAsync(InkscapeCommand command) {
        executorService.submit(command::execute);
    }

    /**
     * Executes the given InkscapeCommand asynchronously using an executor
     * service.
     *
     * @param command the InkscapeCommand to be executed
     * @return a Future representing the result of the asynchronous execution,
     * which will be true if the command executed successfully, or false if an
     * exception occurred
     */
    public Future<Boolean> executeCommand(InkscapeCommand command) {
        return executorService.submit(() -> {
            try {
                command.execute();
                return true; // Indicating success
            } catch (Exception e) {
                e.printStackTrace();
                return false; // Indicating failure
            }
        });
    }

//    public static void main(String[] args) {
//        InkscapeCommandCreator creator = new InkscapeCommandCreator();
//        List<InkscapeOptions> tasks = new ArrayList<>();
//
//        InkscapeOptions options1 = new InkscapeOptions();
//        options1.setInputFilePath("/home/saleem/Pictures/color_logo.svg");
//        options1.setOutputFilePath("/home/saleem/Pictures/tp/color_logo.png");
//        options1.setExportType("png");
//        tasks.add(options1);
//
//        InkscapeOptions options3 = new InkscapeOptions();
//        options3.setInputFilePath("/home/saleem/Pictures/color_logo.svg");
//        options3.setOutputFilePath("/home/saleem/Pictures/tp/color_logo.eps");
//        options3.setExportType("eps");
//        tasks.add(options3);
//
//
//        InkscapeOptions options5 = new InkscapeOptions();
//        options5.setInputFilePath("/home/saleem/Pictures/color_logo.svg");
//        options5.setOutputFilePath("/home/saleem/Pictures/tp/color_logo.pdf");
//        options5.setExportType("pdf");
//        tasks.add(options5);
//
//        for (InkscapeOptions options : tasks) {
//            InkscapeCommand command = creator.createInkscapeCommand(options);
//            creator.executeCommandAsync(command);
//        }
//    }
}
