/*
 * The MIT License
 * Copyright (c) 2024-2025 Elite India
 *
 * Author: Saleem Ahmad
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.elite.india.sa.thirdparty;

/**
 *
 * @author saleem
 */
import com.elite.india.sa.GlobalProperties;
import java.util.List;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.PrintStream;

public class InkscapeCommand {

    private List<String> cmdArray;
    private String cmd;
    private String inputFile;
    private static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Constructs an InkscapeCommand with the specified command array, command,
     * and input file.
     *
     * @param cmdArray the list of command arguments
     * @param cmd the command to be executed
     * @param inputFile the input file for the command
     */
    public InkscapeCommand(List<String> cmdArray, String cmd, String inputFile) {
        this.cmdArray = cmdArray;
        this.cmd = cmd;
        this.inputFile = inputFile;
        if (GlobalProperties.isDebug) {
            if (GlobalProperties.inkscapeVersion.equalsIgnoreCase("new")) {
                System.out.println("cmdArray:" + this.cmdArray.toString());
            } else {
                System.out.println("cmd:" + this.cmd);
            }
        }
        // ✅ Redirect Java Console Output to Node.js Console
        PrintStream consoleOut = System.out;
        PrintStream consoleErr = System.err;

        System.setOut(new PrintStream(System.out) {
            public void println(String s) {
                super.println("[GTGS-LOG] " + s);
            }
        });

        System.setErr(new PrintStream(System.err) {
            public void println(String s) {
                super.println("[CORE-ERROR] " + s);
            }
        });

        System.out.println("✅ InkscapeCommand Class Initialized!");
    }

    /**
     * Executes the Inkscape command specified by the cmdArray.
     *
     * This method performs the following steps: 1. Initializes a status map
     * with the input file and a "Started" status. 2. Logs the initial status as
     * a JSON string. 3. Creates and starts a process using the command array
     * (cmdArray). 4. Reads and optionally logs the output from the process. 5.
     * Waits for the process to complete and updates the status to "Completed"
     * or "Failed" based on the exit code. 6. Logs the final status as a JSON
     * string.
     *
     * If an exception occurs during the execution, it catches the exception,
     * updates the status to "Error" with the exception message, and logs it as
     * a JSON string.
     *
     * In case of an error while logging the status, it prints the stack trace
     * of the JSON exception.
     *
     * @throws Exception if an error occurs during the execution of the command
     * or while logging the status.
     */
    public void execute() {
        try {
            Map<String, String> status = new HashMap<>();
            status.put("file", inputFile);
            status.put("status", "Started");
            if (GlobalProperties.isDebug) {
                System.out.println(objectMapper.writeValueAsString(status));
            }

            ProcessBuilder processBuilder = new ProcessBuilder(cmdArray);
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.contains("item_to_outline") && !line.contains("CRITICAL") && !line.contains("assertion 'this->document != nullptr' failed")) {
                    // Optionally log other messages if needed, currently ignored
                }
            }

            int exitCode = process.waitFor();
            process.destroy();  // Ensure process is killed
            status.put("status", exitCode == 0 ? "Completed" : "Failed");
            if (GlobalProperties.isDebug) {
                System.out.println(objectMapper.writeValueAsString(status));
            }

        } catch (Exception e) {
            try {
                Map<String, String> status = new HashMap<>();
                status.put("file", inputFile);
                status.put("status", "Error: " + e.getMessage());
                System.out.println(objectMapper.writeValueAsString(status));
            } catch (Exception jsonException) {
                jsonException.printStackTrace();
            }
        }
    }

}
