/*
 * The MIT License
 * Copyright (c) 2024-2025 Elite India
 *
 * Author: Saleem Ahmad
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.elite.india.sa.thirdparty;

/**
 *
 * @author saleem
 */
import com.elite.india.sa.GlobalProperties;
import java.io.PrintStream;
import java.util.List;

public class InkscapeOptions {

    private String version;
    private String inputFilePath;
    private String outputFilePath;
    private String exportType;
    private Integer dpi;
    private Integer width;
    private Integer height;
    private String area;
    private Integer margin;
    private String background;
    private Double backgroundOpacity;
    private String exportId;
    private boolean exportIdOnly;
    private boolean exportPlainSvg;
    private List<String> additionalOptions;

    // Constructor
    public InkscapeOptions() {
        // ✅ Redirect Java Console Output to Node.js Console
        PrintStream consoleOut = System.out;
        PrintStream consoleErr = System.err;

        System.setOut(new PrintStream(System.out) {
            public void println(String s) {
                super.println("[GTGS-LOG] " + s);
            }
        });

        System.setErr(new PrintStream(System.err) {
            public void println(String s) {
                super.println("[CORE-ERROR] " + s);
            }
        });

//        System.out.println("✅ InkscapeOptions Class Initialized!");
    }

    /**
     * Retrieves the version of inkscape.
     *
     * @return the version as a string old or new.
     */
    public String getVersion() {
        if (this.version == null || this.version.isEmpty()) {
            this.version = "new";
        }
        GlobalProperties.inkscapeVersion=this.version;
        return version;
    }

    /**
     * Sets the inkscape version as old (below version 1) or as new (from
     * version 1.0 plus).
     *
     * @param version the path to the input file
     */
    public void setVersion(String version) {
        this.version = version;
        if (this.version == null || this.version.isEmpty()) {
            this.version = "new";
        }
         GlobalProperties.inkscapeVersion=this.version;
    }

    /**
     * Retrieves the file path of the input file.
     *
     * @return the input file path as a String.
     */
    public String getInputFilePath() {
        return inputFilePath;
    }

    /**
     * Sets the file path for the input file.
     *
     * @param inputFilePath the path to the input file
     */
    public void setInputFilePath(String inputFilePath) {
        this.inputFilePath = inputFilePath;
    }

    /**
     * Retrieves the file path where the output will be saved.
     *
     * @return the output file path as a String.
     */
    public String getOutputFilePath() {
        return outputFilePath;
    }

    /**
     * Sets the output file path.
     *
     * @param outputFilePath the path where the output file will be saved
     */
    public void setOutputFilePath(String outputFilePath) {
        this.outputFilePath = outputFilePath;
    }

    /**
     * Retrieves the export type.
     *
     * @return the export type as a String.
     */
    public String getExportType() {
        return exportType;
    }

    /**
     * Sets the export type for the Inkscape options.
     *
     * @param exportType the type of export to be set
     */
    public void setExportType(String exportType) {
        this.exportType = exportType;
    }

    /**
     * Retrieves the DPI (dots per inch) setting.
     *
     * @return the DPI value as an Integer.
     */
    public Integer getDpi() {
        return dpi;
    }

    /**
     * Sets the DPI (dots per inch) value.
     *
     * @param dpi the DPI value to set
     */
    public void setDpi(Integer dpi) {
        this.dpi = dpi;
    }

    /**
     * Retrieves the width value.
     *
     * @return the width as an Integer
     */
    public Integer getWidth() {
        return width;
    }

    /**
     * Sets the width for the Inkscape options.
     *
     * @param width the width to set, as an Integer
     */
    public void setWidth(Integer width) {
        this.width = width;
    }

    /**
     * Retrieves the height value.
     *
     * @return the height as an Integer
     */
    public Integer getHeight() {
        return height;
    }

    /**
     * Sets the height.
     *
     * @param height the height to set
     */
    public void setHeight(Integer height) {
        this.height = height;
    }

    /**
     * Retrieves the area.
     *
     * @return the area as a String.
     */
    public String getArea() {
        return area;
    }

    /**
     * Sets the area for the Inkscape options.
     *
     * @param area the area to be set
     */
    public void setArea(String area) {
        this.area = area;
    }

    /**
     * Retrieves the margin value.
     *
     * @return the margin as an Integer.
     */
    public Integer getMargin() {
        return margin;
    }

    /**
     * Sets the margin value.
     *
     * @param margin the margin to set
     */
    public void setMargin(Integer margin) {
        this.margin = margin;
    }

    /**
     * Retrieves the background setting.
     *
     * @return the background as a String.
     */
    public String getBackground() {
        return background;
    }

    /**
     * Sets the background property.
     *
     * @param background the background value to set
     */
    public void setBackground(String background) {
        this.background = background;
    }

    /**
     * Retrieves the background opacity value.
     *
     * @return the background opacity as a Double.
     */
    public Double getBackgroundOpacity() {
        return backgroundOpacity;
    }

    /**
     * Sets the background opacity.
     *
     * @param backgroundOpacity the opacity value for the background, where 0.0
     * is fully transparent and 1.0 is fully opaque.
     */
    public void setBackgroundOpacity(Double backgroundOpacity) {
        this.backgroundOpacity = backgroundOpacity;
    }

    /**
     * Retrieves the export ID.
     *
     * @return the export ID as a String.
     */
    public String getExportId() {
        return exportId;
    }

    /**
     * Sets the export ID to be used.
     *
     * @param exportId the ID to be set for export
     */
    public void setExportId(String exportId) {
        this.exportId = exportId;
    }

    /**
     * Checks if the export is limited to a specific ID only.
     *
     * @return true if only a specific ID is exported, false otherwise.
     */
    public boolean isExportIdOnly() {
        return exportIdOnly;
    }

    /**
     * Sets the flag to export only the specified ID.
     *
     * @param exportIdOnly true to export only the specified ID, false otherwise
     */
    public void setExportIdOnly(boolean exportIdOnly) {
        this.exportIdOnly = exportIdOnly;
    }

    /**
     * Checks if the export option for plain SVG is enabled.
     *
     * @return true if plain SVG export is enabled, false otherwise.
     */
    public boolean isExportPlainSvg() {
        return exportPlainSvg;
    }

    /**
     * Sets the option to export plain SVG.
     *
     * @param exportPlainSvg true to export plain SVG, false otherwise
     */
    public void setExportPlainSvg(boolean exportPlainSvg) {
        this.exportPlainSvg = exportPlainSvg;
    }

    /**
     * Retrieves the list of additional options.
     *
     * @return a list of additional options.
     */
    public List<String> getAdditionalOptions() {
        return additionalOptions;
    }

    /**
     * Sets the additional options for Inkscape.
     *
     * @param additionalOptions a list of additional options to be used by
     * Inkscape
     */
    public void setAdditionalOptions(List<String> additionalOptions) {
        this.additionalOptions = additionalOptions;
    }

    @Override
    public String toString() {
        return "InkscapeOptions{"
                + "inputFilePath='" + inputFilePath + '\''
                + ", outputFilePath='" + outputFilePath + '\''
                + ", exportType='" + exportType + '\''
                + ", dpi=" + dpi
                + ", width=" + width
                + ", height=" + height
                + ", area='" + area + '\''
                + ", margin=" + margin
                + ", background='" + background + '\''
                + ", backgroundOpacity=" + backgroundOpacity
                + ", exportId='" + exportId + '\''
                + ", exportIdOnly=" + exportIdOnly
                + ", exportPlainSvg=" + exportPlainSvg
                + ", additionalOptions=" + additionalOptions
                + '}';
    }
}
