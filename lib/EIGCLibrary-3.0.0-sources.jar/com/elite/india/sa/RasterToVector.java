/*
 * The MIT License
 * Copyright (c) 2024-2025 Elite India
 *
 * Author: Saleem Ahmad
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.elite.india.sa;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import java.util.HashMap;
import java.util.Map;
import javax.imageio.IIOImage;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.graphics.image.LosslessFactory;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

/**
 * The RasterToVector class provides functionality to convert raster images to
 * various vector formats such as SVG, EPS, TIFF, and AI. It supports scaling
 * and color reduction of the input image.
 *
 * <p>
 * Usage example:</p>
 * <pre>
 * {@code
 * RasterToVector converter = new RasterToVector(inputImagePath, outputFilePath, scaleFactor, colorReductionLevel);
 * converter.convertToSVG(); // Convert to SVG
 * converter.convertToEPS(); // Convert to EPS
 * converter.convertToTIFF(); // Convert to TIFF
 * converter.convertToAI(); // Convert to AI
 * }
 * </pre>
 *
 * <p>
 * Constructor parameters:</p>
 * <ul>
 * <li>{@code inputImagePath} - the path to the input image file</li>
 * <li>{@code outputFilePath} - the path to the output file</li>
 * <li>{@code scaleFactor} - the factor by which to scale the image; must be >=
 * 1.0</li>
 * <li>{@code colorReductionLevel} - the level of color reduction to apply; must
 * be >= 0</li>
 * </ul>
 *
 * <p>
 * Methods:</p>
 * <ul>
 * <li>{@code convertToSVG()} - Converts the raster image to an SVG format and
 * saves it to a file.</li>
 * <li>{@code convertToEPS()} - Converts the raster image to an EPS format and
 * saves it to a file.</li>
 * <li>{@code convertToTIFF()} - Converts the raster image to a TIFF format and
 * saves it to a file.</li>
 * <li>{@code convertToAI()} - Converts the raster image to an AI format and
 * saves it to a file.</li>
 * </ul>
 *
 * <p>
 * Private helper methods:</p>
 * <ul>
 * <li>{@code scaleImage(BufferedImage img, double scale)} - Scales the given
 * BufferedImage by the specified scale factor.</li>
 * <li>{@code reduceColors(BufferedImage img, int levels)} - Reduces the number
 * of colors in the given BufferedImage.</li>
 * <li>{@code generateOptimizedSVG()} - Generates an optimized SVG
 * representation of the image.</li>
 * <li>{@code generateOptimizedEPS()} - Generates an optimized EPS
 * representation of the image.</li>
 * <li>{@code saveSVG(String svgData)} - Saves the provided SVG data to a file
 * specified by the outputFilePath.</li>
 * <li>{@code saveEPS(String epsData)} - Saves the given EPS data to a file
 * specified by the outputFilePath.</li>
 * <li>{@code saveOptimizedTIFF(BufferedImage image)} - Saves the given
 * BufferedImage as an optimized TIFF file using LZW compression.</li>
 * <li>{@code saveOptimizedAI(BufferedImage image)} - Saves the given
 * BufferedImage as an optimized AI (PDF) file.</li>
 * </ul>
 */
public class RasterToVector {

    private BufferedImage image;
    private String outputFilePath;
    private double scaleFactor;
    private int colorReductionLevel;

    /**
     * Constructs a RasterToVector object with the specified parameters.
     *
     * @param inputImagePath the path to the input image file
     * @param outputFilePath the path to the output file
     * @param scaleFactor the factor by which to scale the image; must be >= 1.0
     * @param colorReductionLevel the level of color reduction to apply; must be
     * >= 0
     * @throws IOException if an error occurs during reading the input image
     * file
     */
    public RasterToVector(String inputImagePath, String outputFilePath, double scaleFactor, int colorReductionLevel) throws IOException {
        try {
            this.image = ImageIO.read(new File(inputImagePath));
            this.outputFilePath = outputFilePath;
            this.scaleFactor = scaleFactor;
            this.colorReductionLevel = colorReductionLevel;

            if (scaleFactor < 1.0) {
                this.image = scaleImage(image, scaleFactor);
            }

            if (colorReductionLevel > 0) {
                this.image = reduceColors(image, colorReductionLevel);
            }

            // ✅ Redirect Java Console Output to Node.js Console
            PrintStream consoleOut = System.out;
            PrintStream consoleErr = System.err;

            System.setOut(new PrintStream(System.out) {
                public void println(String s) {
                    super.println("[GTGS-LOG] " + s);
                }
            });

            System.setErr(new PrintStream(System.err) {
                public void println(String s) {
                    super.println("[CORE-ERROR] " + s);
                }
            });

            System.out.println("✅ RasterToVector Class Initialized!");
        } catch (Exception e) {
            e.getStackTrace();
        }
    }

    /**
     * Converts the raster image to an SVG format. This method generates an
     * optimized SVG representation of the raster image and saves it to a file.
     *
     * @throws IOException if an I/O error occurs during the SVG generation or
     * saving process.
     */
    public String convertToSVG() throws IOException {
        String response = "";
        try {
            String svgData = generateOptimizedSVG();
            saveSVG(svgData);
            response = "{\"status\":true,\"msg\":\"Image has been created successfully\"}";
        } catch (Exception e) {
            e.getStackTrace();
            response = "{\"status\":false,\"msg\":\"" + e.getMessage() + "\"}";
        }
        return response;
    }

    /**
     * Converts the current raster image to an EPS (Encapsulated PostScript)
     * format. This method generates optimized EPS data and saves it to a file.
     *
     * @throws IOException if an I/O error occurs during the conversion or
     * saving process.
     */
    public String convertToEPS() throws IOException {
        String response = "";
        try {
            String epsData = generateOptimizedEPS();
            saveEPS(epsData);
            response = "{\"status\":true,\"msg\":\"Image has been created successfully\"}";
        } catch (Exception e) {
            e.getStackTrace();
            response = "{\"status\":false,\"msg\":\"" + e.getMessage() + "\"}";
        }
        return response;
    }

    /**
     * Converts the current image to a TIFF format and saves it.
     *
     * @throws IOException if an error occurs during the saving process.
     */
    public String convertToTIFF() throws IOException {
        String response = "";
        try {
            saveOptimizedTIFF(image);

            response = "{\"status\":true,\"msg\":\"Image has been created successfully\"}";
        } catch (Exception e) {
            e.getStackTrace();
            response = "{\"status\":false,\"msg\":\"" + e.getMessage() + "\"}";
        }
        return response;
    }

    /**
     * Converts the current image to an Adobe Illustrator (AI) file format. This
     * method optimizes the image and saves it as an AI file.
     *
     * @throws IOException if an I/O error occurs during the conversion process.
     */
    public String convertToAI() throws IOException {
        String response = "";
        try {
            saveOptimizedAI(image);
            response = "{\"status\":true,\"msg\":\"Image has been created successfully\"}";
        } catch (Exception e) {
            e.getStackTrace();
            response = "{\"status\":false,\"msg\":\"" + e.getMessage() + "\"}";
        }
        return response;
    }

    /**
     * Scales the given BufferedImage by the specified scale factor.
     *
     * @param img the BufferedImage to be scaled
     * @param scale the scale factor to apply to the image dimensions
     * @return a new BufferedImage that is scaled to the specified dimensions
     */
    private BufferedImage scaleImage(BufferedImage img, double scale) {
        int newWidth = (int) (img.getWidth() * scale);
        int newHeight = (int) (img.getHeight() * scale);
        Image scaled = img.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        BufferedImage newImg = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = newImg.createGraphics();
        g.drawImage(scaled, 0, 0, null);
        g.dispose();
        return newImg;
    }

    /**
     * Reduces the number of colors in the given BufferedImage.
     *
     * @param img the original BufferedImage to be processed
     * @param levels the number of color levels to reduce to
     * @return a new BufferedImage with reduced colors
     */
    private BufferedImage reduceColors(BufferedImage img, int levels) {
        BufferedImage reducedImg = null;
        try {
            int width = img.getWidth();
            int height = img.getHeight();
            reducedImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    int pixel = img.getRGB(x, y);
                    Color color = new Color(pixel, true);
                    int red = (color.getRed() / levels) * levels;
                    int green = (color.getGreen() / levels) * levels;
                    int blue = (color.getBlue() / levels) * levels;
                    Color newColor = new Color(red, green, blue, color.getAlpha());
                    reducedImg.setRGB(x, y, newColor.getRGB());
                }
            }
        } catch (Exception e) {
            e.getStackTrace();
        }
        return reducedImg;
    }

    /**
     * Generates an optimized SVG representation of the image. The method scans
     * the image and creates SVG paths for contiguous regions of the same color.
     * It attempts to merge adjacent pixels into larger rectangles to reduce the
     * number of SVG elements.
     *
     * @return A string containing the SVG representation of the image.
     */
    private String generateOptimizedSVG() {
        int width = image.getWidth();
        int height = image.getHeight();
        StringBuilder svg = new StringBuilder();
        try {
            svg.append("<svg xmlns='http://www.w3.org/2000/svg' width='")
                    .append(width)
                    .append("' height='")
                    .append(height)
                    .append("' viewBox='0 0 ")
                    .append(width)
                    .append(" ")
                    .append(height)
                    .append("'>\n");

            Map<String, StringBuilder> paths = new HashMap<>();

            boolean[][] visited = new boolean[height][width];

            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    if (visited[y][x]) {
                        continue;
                    }
                    int pixel = image.getRGB(x, y);
                    Color color = new Color(pixel, true);
                    if (color.getAlpha() == 0) {
                        continue;
                    }

                    String hexColor = String.format("#%02x%02x%02x", color.getRed(), color.getGreen(), color.getBlue());
                    int w = 1, h = 1;

                    while (x + w < width && image.getRGB(x + w, y) == pixel) {
                        w++;
                    }
                    boolean canGrowHeight = true;

                    while (canGrowHeight && y + h < height) {
                        for (int i = 0; i < w; i++) {
                            if (image.getRGB(x + i, y + h) != pixel) {
                                canGrowHeight = false;
                                break;
                            }
                        }
                        if (canGrowHeight) {
                            h++;
                        }
                    }

                    for (int i = 0; i < h; i++) {
                        for (int j = 0; j < w; j++) {
                            visited[y + i][x + j] = true;
                        }
                    }

                    String rectPath = String.format("M%d %dh%dv%dh-%dv-%dh%dZ ", x, y, w, h, w, h, w);

                    paths.putIfAbsent(hexColor, new StringBuilder());
                    paths.get(hexColor).append(rectPath);
                }
            }

            for (Map.Entry<String, StringBuilder> entry : paths.entrySet()) {
                svg.append("<path fill='").append(entry.getKey()).append("' d='").append(entry.getValue()).append("'/>\n");
            }

            svg.append("</svg>");
        } catch (Exception e) {
            e.getStackTrace();
        }
        return svg.toString();
    }

    /**
     * Generates an optimized Encapsulated PostScript (EPS) representation of
     * the image. The method analyzes the image and groups similar-colored
     * regions into rectangles to minimize the number of drawing commands in the
     * EPS output.
     *
     * @return A string containing the EPS representation of the image.
     */
    private String generateOptimizedEPS() {
        int width = image.getWidth();
        int height = image.getHeight();
        StringBuilder eps = new StringBuilder();
        try {
            // EPS Header
            eps.append("%!PS-Adobe-3.0 EPSF-3.0\n");
            eps.append("%%BoundingBox: 0 0 ").append(width).append(" ").append(height).append("\n");
            eps.append("%%EndComments\n");

            // Group similar-colored regions into rectangles
            boolean[][] visited = new boolean[height][width];

            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    if (visited[y][x]) {
                        continue;
                    }
                    int pixel = image.getRGB(x, y);
                    Color color = new Color(pixel, true);
                    if (color.getAlpha() == 0) {
                        continue;
                    }

                    int w = 1, h = 1;

                    while (x + w < width && image.getRGB(x + w, y) == pixel) {
                        w++;
                    }
                    boolean canGrowHeight = true;

                    while (canGrowHeight && y + h < height) {
                        for (int i = 0; i < w; i++) {
                            if (image.getRGB(x + i, y + h) != pixel) {
                                canGrowHeight = false;
                                break;
                            }
                        }
                        if (canGrowHeight) {
                            h++;
                        }
                    }

                    for (int i = 0; i < h; i++) {
                        for (int j = 0; j < w; j++) {
                            visited[y + i][x + j] = true;
                        }
                    }

                    eps.append(String.format("%.2f %.2f %.2f setrgbcolor\n", color.getRed() / 255.0, color.getGreen() / 255.0, color.getBlue() / 255.0));
                    eps.append(String.format("%d %d %d %d rectfill\n", x, height - y - h, w, h));
                }
            }

            eps.append("%%EOF\n");
        } catch (Exception e) {
            e.getStackTrace();
        }
        return eps.toString();
    }

    /**
     * Saves the provided SVG data to a file specified by the outputFilePath.
     *
     * @param svgData the SVG data to be saved
     * @throws IOException if an I/O error occurs while writing the file
     */
    private void saveSVG(String svgData) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
            writer.write(svgData);
        } catch (Exception e) {
            e.getStackTrace();
        }
        if (GlobalProperties.isDebug) {
            System.out.println("Optimized SVG saved: " + outputFilePath);
        }
    }

    /**
     * Saves the given EPS (Encapsulated PostScript) data to a file specified by
     * the outputFilePath.
     *
     * @param epsData The EPS data to be saved.
     * @throws IOException If an I/O error occurs while writing the file.
     */
    private void saveEPS(String epsData) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
            writer.write(epsData);
        } catch (Exception e) {
            e.getStackTrace();
        }
        if (GlobalProperties.isDebug) {
            System.out.println("Optimized EPS saved: " + outputFilePath);
        }
    }

    /**
     * Saves the given BufferedImage as an optimized TIFF file using LZW
     * compression.
     *
     * @param image the BufferedImage to be saved as a TIFF file
     * @throws IOException if an error occurs during writing the file
     */
    private void saveOptimizedTIFF(BufferedImage image) throws IOException {
        File outputFile = new File(outputFilePath);
        ImageWriter writer = ImageIO.getImageWritersByFormatName("TIFF").next();
        ImageWriteParam param = writer.getDefaultWriteParam();
        param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        param.setCompressionType("LZW"); // Use LZW compression for optimization

        try (ImageOutputStream output = ImageIO.createImageOutputStream(outputFile)) {
            writer.setOutput(output);
            writer.write(null, new IIOImage(image, null, null), param);
        } catch (Exception e) {
            e.getStackTrace();
        }
        if (GlobalProperties.isDebug) {
            System.out.println("Optimized TIFF saved: " + outputFilePath);
        }
    }

    /**
     * Saves the given BufferedImage as an optimized AI (PDF) file.
     *
     * @param image the BufferedImage to be saved
     * @throws IOException if an I/O error occurs while saving the file
     */
    private void saveOptimizedAI(BufferedImage image) throws IOException {
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage();
            document.addPage(page);

            PDImageXObject pdImage = LosslessFactory.createFromImage(document, image);
            try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
                contentStream.drawImage(pdImage, 0, 0);
            } catch (Exception ee) {
                ee.getStackTrace();
            }
            document.save(outputFilePath);
        } catch (Exception e) {
            e.getStackTrace();
        }
        if (GlobalProperties.isDebug) {
            System.out.println("Optimized AI (PDF) saved: " + outputFilePath);
        }
    }

    public static void main(String[] args) {
        try {
            String inputImage = "/home/saleem/Pictures/spiderman.png"; // Input raster image
            String outputSVG = "/home/saleem/Pictures/spiderman.svg";
            String outputEPS = "/home/saleem/Pictures/spiderman.eps";
            String outputTIFF = "/home/saleem/Pictures/spiderman.tiff";
            String outputAI = "/home/saleem/Pictures/spiderman.ai";

            double scaleFactor = 0.5;
            int colorReductionLevel = 64;

            RasterToVector converter = new RasterToVector(inputImage, outputSVG, scaleFactor, colorReductionLevel);
            converter.convertToSVG(); // Convert to SVG
            converter = new RasterToVector(inputImage, outputEPS, scaleFactor, colorReductionLevel);
            converter.convertToEPS(); // Convert to EPS
            converter = new RasterToVector(inputImage, outputTIFF, scaleFactor, colorReductionLevel);
            converter.convertToTIFF(); // Convert to TIFF
            converter = new RasterToVector(inputImage, outputAI, scaleFactor, colorReductionLevel);
            converter.convertToAI(); // Convert to AI

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
