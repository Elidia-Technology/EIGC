/*
 * The MIT License
 * Copyright (c) 2024-2025 Elite India
 *
 * Author: Saleem Ahmad
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.elite.india.sa;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jsoup.HttpStatusException;

public class HtmlSizeUtil {

    public static Dimensions getBodyDimensions(String htmlContent) {
        Document doc = Jsoup.parse(htmlContent);
        Element body = doc.body();

        if (body == null) {
            return new Dimensions(640, 480); // Default dimensions
        }

        // Extract width and height from styles
        int[] dimensions = extractDimensions(body);
        
        // If no valid dimensions found, use default values
        if (dimensions[0] == 0 || dimensions[1] == 0) {
            Element firstElement = body.children().first();
            if (firstElement != null) {
                dimensions = extractDimensions(firstElement);
            }
        }

        // If still missing dimensions, fallback to defaults
        if (dimensions[0] == 0) dimensions[0] = 0; // Default width
        if (dimensions[1] == 0) dimensions[1] = 0; // Default height

        System.out.println("Width & Height: " + dimensions[0] + ", " + dimensions[1]);
        return new Dimensions(dimensions[0], dimensions[1]);
    }

    private static int[] extractDimensions(Element element) {
        if (element == null) {
            return new int[]{0, 0};
        }

        String style = element.attr("style").toLowerCase();
        double scale = extractScale(style);

        int width = extractAndConvertToPixels(style, "width");
        int height = extractAndConvertToPixels(style, "height");

        // Apply scaling if found
        if (scale != 1.0) {
            width = (int) (width * scale);
            height = (int) (height * scale);
        }

        return new int[]{width, height};
    }

    private static double extractScale(String style) {
        Pattern scalePattern = Pattern.compile("scale\\((\\d*\\.?\\d+)\\)");
        Matcher matcher = scalePattern.matcher(style);
        if (matcher.find()) {
            return Double.parseDouble(matcher.group(1));
        }
        return 1.0; // Default scale
    }

    private static int extractAndConvertToPixels(String style, String property) {
        Pattern pattern = Pattern.compile(property + "\\s*:\\s*([0-9.]+)(px|cm|mm|in|pt|pc|%)?");
        Matcher matcher = pattern.matcher(style);
        if (matcher.find()) {
            double value = Double.parseDouble(matcher.group(1));
            String unit = matcher.group(2) != null ? matcher.group(2) : "px"; // Default to px
            if ("%".equals(unit)) {
                return 0; // Ignore percentage values
            }
            return convertToPixels(value, unit);
        }
        return 0;
    }

    private static int convertToPixels(double value, String unit) {
        switch (unit) {
            case "cm":
                return (int) (value * 37.8);
            case "mm":
                return (int) (value * 3.78);
            case "in":
                return (int) (value * 96);
            case "pt":
                return (int) (value * 1.33);
            case "pc":
                return (int) (value * 16);
            default:
                return (int) value;
        }
    }

    public static Dimensions getBodyDimensionsFromFile(String filePathOrUrl) {
        Document doc = null;
        System.out.println("Processing: " + filePathOrUrl);

        try {
            if (filePathOrUrl.startsWith("http://") || filePathOrUrl.startsWith("https://")) {
                doc = Jsoup.connect(filePathOrUrl)
                        .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36")
                        .timeout(10000) // 10 seconds timeout
                        .ignoreHttpErrors(true) // Do not throw errors if status is not 200
                        .ignoreContentType(true) // Bypass content restrictions
                        .referrer("http://www.google.com") // Spoof referrer
                        .get();
                System.out.println("Fetched Document: " + doc.title());

            } else if (filePathOrUrl.startsWith("file:///")) {
                String localPath = filePathOrUrl.replace("file:///", "/");
                File file = new File(localPath);
                doc = Jsoup.parse(file, "UTF-8");

            } else {
                File file = new File(filePathOrUrl);
                doc = Jsoup.parse(file, "UTF-8");
            }

            return getBodyDimensions(doc.html());

        } catch (HttpStatusException e) {
            System.out.println("[ERROR] HTTP error fetching URL: " + e.getStatusCode() + " - " + e.getMessage());
        } catch (IOException e) {
            System.out.println("[ERROR] File or URL read error: " + e.getMessage());
        }

        return new Dimensions(0, 0); // Fallback default size
    }

    public static void main(String[] args) {
        String htmlString = "<html><body><div style='width: 10cm; height: 5cm;'></div></body></html>";

        Dimensions dimensions = getBodyDimensions(htmlString);
        System.out.println("Final Width: " + dimensions.getWidth() + "px, Height: " + dimensions.getHeight() + "px");
    }
}
