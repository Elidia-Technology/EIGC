/*
 * The MIT License
 * Copyright (c) 2024-2025 Elite India
 *
 * Author: Saleem Ahmad
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.elite.india.sa;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;

/**
 * The RasterToSvgHigh class provides functionality to convert a raster image to an SVG format.
 * It reads an image from a specified input path, converts it to an SVG with colored rectangles,
 * and saves the resulting SVG file to a specified output path.
 *
 * <p>Usage example:</p>
 * <pre>
 * {@code
 * try {
 *     String inputImage = "/path/to/input/image.png";
 *     String outputSVG = "/path/to/output/image.svg";
 *
 *     RasterToSvgHigh converter = new RasterToSvgHigh(inputImage, outputSVG);
 *     converter.convertToSVG();
 * } catch (IOException e) {
 *     e.printStackTrace();
 * }
 * }
 * </pre>
 *
 * <p>Methods:</p>
 * <ul>
 *   <li>{@link #RasterToSvgHigh(String, String)} - Constructs a RasterToSvgHigh object with specified input and output paths.</li>
 *   <li>{@link #convertToSVG()} - Converts the raster image to SVG format and saves it.</li>
 *   <li>{@link #generateColoredSVG()} - Generates an SVG representation of the image with colored rectangles.</li>
 *   <li>{@link #saveSVG(String)} - Saves the provided SVG data to a file.</li>
 * </ul>
 */
public class RasterToSvgHigh {
    private BufferedImage image;
    private String outputFilePath;

    /**
     * Constructs a RasterToSVGHigh object that reads an image from the specified input path
     * and sets the output file path.
     *
     * @param inputImagePath the path to the input image file
     * @param outputFilePath the path to the output file where the SVG will be saved
     * @throws IOException if an error occurs during reading the input image file
     */
    public RasterToSvgHigh(String inputImagePath, String outputFilePath) throws IOException {
        this.image = ImageIO.read(new File(inputImagePath));
        this.outputFilePath = outputFilePath;
    }

    /**
     * Converts a raster image to an SVG format with colors and saves the resulting SVG file.
     *
     * @throws IOException if an I/O error occurs during the conversion or saving process.
     */
    public void convertToSVG() throws IOException {
        // Convert raster image to SVG with colors
        String svgData = generateColoredSVG();
        
        // Save the SVG file
        saveSVG(svgData);
    }

    /**
     * Generates an SVG representation of the image with colored rectangles.
     * Each pixel in the image is represented as a 1x1 rectangle in the SVG.
     * Fully transparent pixels are ignored.
     *
     * @return A string containing the SVG representation of the image.
     */
    private String generateColoredSVG() {
        int width = image.getWidth();
        int height = image.getHeight();
        StringBuilder svg = new StringBuilder();

        svg.append("<svg xmlns='http://www.w3.org/2000/svg' width='").append(width)
           .append("' height='").append(height).append("'>\n");

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int pixel = image.getRGB(x, y);
                Color color = new Color(pixel, true);

                if (color.getAlpha() > 0) { // Ignore fully transparent pixels
                    String hexColor = String.format("#%02x%02x%02x", color.getRed(), color.getGreen(), color.getBlue());
                    svg.append("<rect x='").append(x).append("' y='").append(y)
                       .append("' width='1' height='1' fill='").append(hexColor).append("' />\n");
                }
            }
        }

        svg.append("</svg>");
        return svg.toString();
    }

    /**
     * Saves the provided SVG data to a file specified by the outputFilePath.
     *
     * @param svgData The SVG data to be saved.
     * @throws IOException If an I/O error occurs while writing the file.
     */
    private void saveSVG(String svgData) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
            writer.write(svgData);
        }
        System.out.println("SVG saved: " + outputFilePath);
    }

    public static void main(String[] args) {
        try {
            String inputImage = "/home/saleem/Pictures/spiderman.png";
            String outputSVG = "/home/saleem/Pictures/spiderman1.svg";

            RasterToSvgHigh converter = new RasterToSvgHigh(inputImage, outputSVG);
            converter.convertToSVG();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
