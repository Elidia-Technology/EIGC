/*
 * The MIT License
 * Copyright (c) 2024-2025 Elite India
 *
 * Author: Saleem Ahmad
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.elite.india.sa;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import java.util.HashMap;
import java.util.Map;

/**
 * The RasterToSvg class provides functionality to convert raster images to SVG
 * format. It allows scaling and color reduction of the input image before
 * conversion.
 *
 * <p>
 * Usage example:
 * <pre>
 * {@code
 * String inputImage = "/path/to/input/image.png";
 * String outputSVG = "/path/to/output/image.svg";
 * double scaleFactor = 1.0;
 * int colorReductionLevel = 64;
 *
 * RasterToSvg converter = new RasterToSvg(inputImage, outputSVG, scaleFactor, colorReductionLevel);
 * converter.convertToSVG();
 * }
 * </pre>
 * </p>
 *
 * <p>
 * Constructor parameters:
 * <ul>
 * <li>{@code inputImagePath} - the path to the input raster image file</li>
 * <li>{@code outputFilePath} - the path where the output SVG file will be
 * saved</li>
 * <li>{@code scaleFactor} - the factor by which the image should be scaled; if
 * less than 1.0, the image will be scaled down</li>
 * <li>{@code colorReductionLevel} - the level of color reduction to apply; if
 * greater than 0, the image colors will be reduced</li>
 * </ul>
 * </p>
 *
 * <p>
 * Public methods:
 * <ul>
 * <li>{@code convertToSVG()} - Converts raster data to SVG format and saves it
 * to a file.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Private methods:
 * <ul>
 * <li>{@code scaleImage(BufferedImage img, double scale)} - Scales the given
 * BufferedImage by the specified scale factor.</li>
 * <li>{@code reduceColors(BufferedImage img, int levels)} - Reduces the number
 * of colors in the given BufferedImage by quantizing the color levels.</li>
 * <li>{@code generateOptimizedSVG()} - Generates an optimized SVG
 * representation of the image.</li>
 * <li>{@code saveSVG(String svgData)} - Saves the provided SVG data to a file
 * specified by the outputFilePath.</li>
 * </ul>
 * </p>
 */
public class RasterToSvg {

    private BufferedImage image;
    private String outputFilePath;
    private double scaleFactor;
    private int colorReductionLevel;

    /**
     * Constructs a RasterToSVG object that processes an input image and
     * prepares it for SVG conversion.
     *
     * @param inputImagePath the path to the input raster image file
     * @param outputFilePath the path where the output SVG file will be saved
     * @param scaleFactor the factor by which the image should be scaled; if
     * less than 1.0, the image will be scaled down
     * @param colorReductionLevel the level of color reduction to apply; if
     * greater than 0, the image colors will be reduced
     * @throws IOException if an error occurs during reading the input image
     * file
     */
    public RasterToSvg(String inputImagePath, String outputFilePath, double scaleFactor, int colorReductionLevel) throws IOException {
        this.image = ImageIO.read(new File(inputImagePath));
        this.outputFilePath = outputFilePath;
        this.scaleFactor = scaleFactor;
        this.colorReductionLevel = colorReductionLevel;

        if (scaleFactor < 1.0) {
            this.image = scaleImage(image, scaleFactor);
        }

        if (colorReductionLevel > 0) {
            this.image = reduceColors(image, colorReductionLevel);
        }

        // ✅ Redirect Java Console Output to Node.js Console
        PrintStream consoleOut = System.out;
        PrintStream consoleErr = System.err;

        System.setOut(new PrintStream(System.out) {
            public void println(String s) {
                super.println("[GTGS-LOG] " + s);
            }
        });

        System.setErr(new PrintStream(System.err) {
            public void println(String s) {
                super.println("[CORE-ERROR] " + s);
            }
        });

        System.out.println("✅ RasterToSvg Class Initialized!");
    }

    /**
     * Converts raster data to SVG format. This method generates an optimized
     * SVG representation of the raster data and saves it to a file.
     *
     * @throws IOException if an I/O error occurs during the SVG generation or
     * saving process.
     */
    public String convertToSVG() throws IOException {
        String response = "";
        try {
            String svgData = generateOptimizedSVG();
            saveSVG(svgData);
            response = "{\"status\":true,\"msg\":\"Image has been created successfully\"}";
        } catch (Exception e) {
            response = "{\"status\":false,\"msg\":\"" + e.getMessage() + "\"}";
        }
        return response;
    }

    /**
     * Scales the given BufferedImage by the specified scale factor.
     *
     * @param img the BufferedImage to be scaled
     * @param scale the scale factor to apply to the image dimensions
     * @return a new BufferedImage that is scaled to the specified dimensions
     */
    private BufferedImage scaleImage(BufferedImage img, double scale) {
        int newWidth = (int) (img.getWidth() * scale);
        int newHeight = (int) (img.getHeight() * scale);
        Image scaled = img.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        BufferedImage newImg = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = newImg.createGraphics();
        g.drawImage(scaled, 0, 0, null);
        g.dispose();
        return newImg;
    }

    /**
     * Reduces the number of colors in the given BufferedImage by quantizing the
     * color levels.
     *
     * @param img the original BufferedImage to be processed
     * @param levels the number of color levels to reduce to (e.g., 4 will
     * reduce colors to 4 levels per channel)
     * @return a new BufferedImage with reduced color levels
     */
    private BufferedImage reduceColors(BufferedImage img, int levels) {
        int width = img.getWidth();
        int height = img.getHeight();
        BufferedImage reducedImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int pixel = img.getRGB(x, y);
                Color color = new Color(pixel, true);
                int red = (color.getRed() / levels) * levels;
                int green = (color.getGreen() / levels) * levels;
                int blue = (color.getBlue() / levels) * levels;
                Color newColor = new Color(red, green, blue, color.getAlpha());
                reducedImg.setRGB(x, y, newColor.getRGB());
            }
        }
        return reducedImg;
    }

    /**
     * Generates an optimized SVG representation of the image. The method scans
     * the image and groups contiguous pixels of the same color into rectangular
     * paths. These paths are then converted into SVG path elements to minimize
     * the number of elements in the SVG.
     *
     * @return A string containing the SVG representation of the image.
     */
    private String generateOptimizedSVG() {
        int width = image.getWidth();
        int height = image.getHeight();
        StringBuilder svg = new StringBuilder();

        svg.append("<svg xmlns='http://www.w3.org/2000/svg' width='")
                .append(width)
                .append("' height='")
                .append(height)
                .append("' viewBox='0 0 ")
                .append(width)
                .append(" ")
                .append(height)
                .append("'>\n");

        Map<String, StringBuilder> paths = new HashMap<>();

        boolean[][] visited = new boolean[height][width];

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                if (visited[y][x]) {
                    continue;
                }
                int pixel = image.getRGB(x, y);
                Color color = new Color(pixel, true);
                if (color.getAlpha() == 0) {
                    continue;
                }

                String hexColor = String.format("#%02x%02x%02x", color.getRed(), color.getGreen(), color.getBlue());
                int w = 1, h = 1;

                while (x + w < width && image.getRGB(x + w, y) == pixel) {
                    w++;
                }
                boolean canGrowHeight = true;

                while (canGrowHeight && y + h < height) {
                    for (int i = 0; i < w; i++) {
                        if (image.getRGB(x + i, y + h) != pixel) {
                            canGrowHeight = false;
                            break;
                        }
                    }
                    if (canGrowHeight) {
                        h++;
                    }
                }

                for (int i = 0; i < h; i++) {
                    for (int j = 0; j < w; j++) {
                        visited[y + i][x + j] = true;
                    }
                }

                String rectPath = String.format("M%d %dh%dv%dh-%dv-%dh%dZ ", x, y, w, h, w, h, w);

                paths.putIfAbsent(hexColor, new StringBuilder());
                paths.get(hexColor).append(rectPath);
            }
        }

        for (Map.Entry<String, StringBuilder> entry : paths.entrySet()) {
            svg.append("<path fill='").append(entry.getKey()).append("' d='").append(entry.getValue()).append("'/>\n");
        }

        svg.append("</svg>");
        return svg.toString();
    }

    /**
     * Saves the provided SVG data to a file specified by the outputFilePath.
     *
     * @param svgData The SVG data to be saved.
     * @throws IOException If an I/O error occurs while writing the file.
     */
    private void saveSVG(String svgData) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
            writer.write(svgData);
        }
        if (GlobalProperties.isDebug) {
            System.out.println("Optimized SVG saved: " + outputFilePath);
        }
    }

    public static void main(String[] args) {
        try {
//            String inputImage = "/home/saleem/Pictures/spiderman.png";
//            String outputSVG = "/home/saleem/Pictures/spiderman_gpt.svg";

            String inputImage = "/home/saleem/Pictures/spiderman.png"; // Input raster image
            String outputSVG = "/home/saleem/Pictures/spiderman2.svg";
            double scaleFactor = 0.5;
            int colorReductionLevel = 128;

            RasterToSvg converter = new RasterToSvg(inputImage, outputSVG, scaleFactor, colorReductionLevel);
            converter.convertToSVG();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
