/*
 * The MIT License
 * Copyright (c) 2024-2025 Elite India
 *
 * Author: Saleem Ahmad
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.elite.india.sa;

import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;

/**
 * The RasterToRaster class provides functionality to convert raster images from
 * one format to another, with optional resizing and quality adjustments.
 *
 * <p>
 * This class uses the Builder pattern to allow flexible configuration of the
 * conversion parameters. It supports various image formats such as PNG, JPG,
 * BMP, and GIF.</p>
 *
 * <p>
 * Example usage:</p>
 * <pre>
 * {@code
 * RasterToRaster converter = new RasterToRaster.Builder(inputFile, outputFile, "jpg")
 *     .quality(0.9f)
 *     .width(800)
 *     .height(600)
 *     .build();
 * converter.convert();
 * }
 * </pre>
 *
 * <p>
 * Supported parameters:</p>
 * <ul>
 * <li>inputFile: The input image file to be converted.</li>
 * <li>outputFile: The output image file after conversion.</li>
 * <li>outputFormat: The format of the output image (e.g., "jpg", "png").</li>
 * <li>dpi: The resolution of the output image in dots per inch (optional).</li>
 * <li>width: The width of the output image (optional).</li>
 * <li>height: The height of the output image (optional).</li>
 * <li>quality: The quality of the output image (optional, applicable for
 * formats like JPG).</li>
 * </ul>
 *
 * <p>
 * Note: The class ensures that all image plugins are loaded and avoids caching
 * issues by setting ImageIO.setUseCache(false).</p>
 *
 * @see javax.imageio.ImageIO
 * @see javax.imageio.ImageWriteParam
 * @see javax.imageio.ImageWriter
 */
public class RasterToRaster {

    static {
        ImageIO.scanForPlugins(); // Ensure all image plugins are loaded
        ImageIO.setUseCache(false); // Avoid caching issues
    }

    private File inputFile;
    private File outputFile;
    private String outputFormat;
    private Integer dpi;
    private Integer width;
    private Integer height;
    private Float quality;

    /**
     * Constructs a RasterToRaster object using the provided Builder.
     *
     * @param builder the Builder object containing the parameters for the
     * RasterToRaster object
     */
    public RasterToRaster(Builder builder) {
        // ✅ Redirect Java Console Output to Node.js Console
        PrintStream consoleOut = System.out;
        PrintStream consoleErr = System.err;

        System.setOut(new PrintStream(System.out) {
            public void println(String s) {
                super.println("[GTGS-LOG] " + s);
            }
        });

        System.setErr(new PrintStream(System.err) {
            public void println(String s) {
                super.println("[CORE-ERROR] " + s);
            }
        });

        System.out.println("✅ RasterToRaster Class Initialized!");
        this.inputFile = builder.inputFile;
        this.outputFile = builder.outputFile;
        this.outputFormat = builder.outputFormat;
        this.dpi = builder.dpi;
        this.width = builder.width;
        this.height = builder.height;
        this.quality = builder.quality;

    }

    /**
     * Converts an input image to a resized output image with the specified
     * format and quality.
     *
     * @throws IOException if the input image file is invalid or unsupported, or
     * if an error occurs during reading or writing the image.
     */
    public String convert() throws IOException {
        String response = "";
        try {
//            System.out.println("inputFile:" + inputFile);
//            System.out.println("outputFile:" + outputFile);

            BufferedImage inputImage = ImageIO.read(inputFile);
            if (inputImage == null) {
                throw new IOException("Invalid or unsupported image file: " + inputFile.getAbsolutePath());
            }

            // Use original dimensions if width and height are not provided
//            int finalWidth = (width != null) ? width : inputImage.getWidth();
//            int finalHeight = (height != null) ? height : inputImage.getHeight();
            int originalWidth = inputImage.getWidth();
            int originalHeight = inputImage.getHeight();
            int finalWidth, finalHeight;

            if (width != null && height != null) {
                // Both width and height are provided
                finalWidth = width;
                finalHeight = height;
            } else if (width != null) {
                // Width is given, calculate height using aspect ratio
                finalWidth = width;
                finalHeight = (int) ((double) originalHeight / originalWidth * width);
            } else if (height != null) {
                // Height is given, calculate width using aspect ratio
                finalHeight = height;
                finalWidth = (int) ((double) originalWidth / originalHeight * height);
            } else {
                // Neither width nor height is provided, use original dimensions
                finalWidth = originalWidth;
                finalHeight = originalHeight;
            }

//            System.out.println("finalWidth:" + finalWidth);
//            System.out.println("finalHeight:" + finalHeight);
//            System.out.println("quality:" + quality);

            BufferedImage resizedImage = resizeImage(inputImage, finalWidth, finalHeight);
            writeImage(resizedImage, outputFile, outputFormat, (quality != null) ? quality : 1.0f);

            response = "{\"status\":true,\"msg\":\"Image has been created successfully\"}";
        } catch (Exception e) {
//            System.out.println("Exception into convert:" + e.getMessage());
            response = "{\"status\":false,\"msg\":\"" + e.getMessage() + "\"}";
        }
        return response;
    }

    /**
     * Resizes the given BufferedImage to the specified width and height.
     *
     * @param original the original BufferedImage to be resized
     * @param width the desired width of the resized image
     * @param height the desired height of the resized image
     * @return a new BufferedImage that is resized to the specified dimensions
     */
    private static BufferedImage resizeImage(BufferedImage original, int width, int height) {
        int imageType = original.getType();

        // If image type is unknown or doesn't support transparency, check if it should
        if (imageType == BufferedImage.TYPE_CUSTOM) {
            imageType = original.getColorModel().hasAlpha() ? BufferedImage.TYPE_INT_ARGB : BufferedImage.TYPE_INT_RGB;
        }

        BufferedImage resized = new BufferedImage(width, height, imageType);
        Graphics2D g = resized.createGraphics();

        // Enable anti-aliasing and interpolation
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        // If the image supports transparency, enable it
        if (imageType == BufferedImage.TYPE_INT_ARGB || imageType == BufferedImage.TYPE_4BYTE_ABGR) {
            g.setComposite(AlphaComposite.Src);
        }

        g.drawImage(original, 0, 0, width, height, null);
        g.dispose();
        return resized;
    }

    /**
     * Writes a BufferedImage to a file with the specified format and quality.
     *
     * @param image the BufferedImage to be written
     * @param outputFile the file to which the image will be written
     * @param format the format of the output image (e.g., "jpg", "png", "bmp")
     * @param quality the quality of the output image (only applicable for "jpg"
     * and "jpeg" formats)
     * @throws IOException if an error occurs during writing or if no writer is
     * found for the specified format
     */
    private static void writeImage(BufferedImage image, File outputFile, String format, float quality) throws IOException {
        if (!ImageIO.getImageWritersByFormatName(format).hasNext()) {
            throw new IOException("No writer found for format: " + format);
        }

        ImageWriter writer = ImageIO.getImageWritersByFormatName(format).next();
        ImageWriteParam param = writer.getDefaultWriteParam();

        if (format.equalsIgnoreCase("jpg") || format.equalsIgnoreCase("jpeg") || format.equalsIgnoreCase("bmp")) {
            image = convertToRGB(image);
        }

        if (param.canWriteCompressed() && (format.equalsIgnoreCase("jpg") || format.equalsIgnoreCase("jpeg"))) {
            param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
            param.setCompressionQuality(quality);
        }

        try (ImageOutputStream ios = ImageIO.createImageOutputStream(outputFile)) {
            writer.setOutput(ios);
            writer.write(null, new javax.imageio.IIOImage(image, null, null), param);
        }
        writer.dispose();
    }

    /**
     * Converts a given BufferedImage to an RGB image. This method creates a new
     * BufferedImage with the same dimensions as the input image, but with the
     * type TYPE_INT_RGB. It then draws the input image onto the new image,
     * filling any transparent areas with white.
     *
     * @param image the BufferedImage to be converted to RGB
     * @return a new BufferedImage in RGB format
     */
    private static BufferedImage convertToRGB(BufferedImage image) {
        BufferedImage rgbImage = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g = rgbImage.createGraphics();

        // Set white background for transparency areas
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, image.getWidth(), image.getHeight());

        g.drawImage(image, 0, 0, null);
        g.dispose();
        return rgbImage;
    }

    /**
     * Builder class for constructing a RasterToRaster object.
     */
    public static class Builder {

        /**
         * The input file for the raster operation.
         */
        private File inputFile;

        /**
         * The output file for the raster operation.
         */
        private File outputFile;

        /**
         * The format of the output file.
         */
        private String outputFormat;

        /**
         * The dots per inch (DPI) for the output file.
         */
        private Integer dpi;

        /**
         * The width of the output file.
         */
        private Integer width;

        /**
         * The height of the output file.
         */
        private Integer height;

        /**
         * The quality of the output file.
         */
        private Float quality;

        /**
         * Constructs a Builder
         */
        public Builder() {
            // ✅ Redirect Java Console Output to Node.js Console
            PrintStream consoleOut = System.out;
            PrintStream consoleErr = System.err;

            System.setOut(new PrintStream(System.out) {
                public void println(String s) {
                    super.println("[GTGS-LOG] " + s);
                }
            });

            System.setErr(new PrintStream(System.err) {
                public void println(String s) {
                    super.println("[CORE-ERROR] " + s);
                }
            });

            System.out.println("✅ Builder Class Initialized!");
        }

        /**
         * Sets inputFile to be injected into the HTML.
         *
         * @param inputFile the CSS string to be injected
         * @return the Builder instance for method chaining
         */
        public Builder inputFile(String inputFile) {
//            System.out.println("✅ Builder inputFile:"+inputFile);
            this.inputFile = new File(inputFile);
            return this;
        }

        /**
         * Sets outputFile to be injected into the HTML.
         *
         * @param outputFile the CSS string to be injected
         * @return the Builder instance for method chaining
         */
        public Builder outputFile(String outputFile) {
//            System.out.println("✅ Builder outputFile:"+outputFile);
            this.outputFile = new File(outputFile);
            return this;
        }

        /**
         * Sets outputFormat to be injected into the HTML.
         *
         * @param outputFormat the CSS string to be injected
         * @return the Builder instance for method chaining
         */
        public Builder outputFormat(String outputFormat) {
//            System.out.println("✅ Builder outputFormat:"+outputFormat);
            this.outputFormat = outputFormat;
            return this;
        }

        /**
         * Sets the DPI for the output file.
         *
         * @param dpi the DPI value
         * @return the Builder instance
         */
        public Builder dpi(int dpi) {
//            System.out.println("✅ Builder dpi:"+dpi);
            this.dpi = dpi;
            return this;
        }

        /**
         * Sets the width for the output file.
         *
         * @param width the width value
         * @return the Builder instance
         */
        public Builder width(int width) {
//            System.out.println("✅ Builder width:"+width);
            this.width = width;
            return this;
        }

        /**
         * Sets the height for the output file.
         *
         * @param height the height value
         * @return the Builder instance
         */
        public Builder height(int height) {
//            System.out.println("✅ Builder height:"+height);
            this.height = height;
            return this;
        }

        /**
         * Sets the quality for the output file.
         *
         * @param quality the quality value
         * @return the Builder instance
         */
        public Builder quality(float quality) {
//            System.out.println("✅ Builder quality:"+quality);
            this.quality = quality;
            return this;
        }

        /**
         * Builds and returns a RasterToRaster object based on the current state
         * of the Builder.
         *
         * @return a new RasterToRaster object
         */
        public RasterToRaster build() {
//            System.out.println("✅ Builder creating RasterToRaster:");
            return new RasterToRaster(this);
        }
    }

//    public static void main(String[] args) {
//        try {
//            System.out.println("Available formats: " + Arrays.toString(ImageIO.getWriterFormatNames()));
//            String userHome = System.getProperty("user.home");
//            String inputImagePath = userHome + "/Pictures/spiderman.png";
//            File inputFile = new File(inputImagePath);
//
//            new RasterToRaster.Builder(inputFile, new File(userHome + "/Pictures/spiderman.bmp"), "bmp").build().convert();
//            new RasterToRaster.Builder(inputFile, new File(userHome + "/Pictures/spiderman.jpg"), "jpg").quality(0.9f).build().convert();
//            new RasterToRaster.Builder(inputFile, new File(userHome + "/Pictures/spiderman.gif"), "gif").build().convert();
//            new RasterToRaster.Builder(inputFile, new File(userHome + "/Pictures/spiderman2.png"), "png").build().convert();
//            new RasterToRaster.Builder(inputFile, new File(userHome + "/Pictures/spiderman3.png"), "png").dpi(300).build().convert();
//            new RasterToRaster.Builder(inputFile, new File(userHome + "/Pictures/spiderman4.png"), "png").dpi(72).build().convert();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
}
