/*
 * The MIT License
 * Copyright (c) 2024-2025 Elite India
 *
 * Author: Saleem Ahmad
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.elite.india.sa;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.*;
import java.time.Duration;
import java.awt.*;
import java.io.*;
import org.openqa.selenium.chrome.ChromeOptions;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.time.Duration;
import java.util.Base64;
import java.util.Optional;
import java.util.Set;
import javax.imageio.ImageIO;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.devtools.v132.network.Network;
import org.openqa.selenium.devtools.v132.network.model.InterceptionId;

import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.v132.page.Page;
import org.openqa.selenium.devtools.v132.page.model.Viewport;

/**
 * The HtmlToRaster class provides functionality to convert HTML content or web
 * pages to PNG images. It uses Selenium WebDriver to load the content and take
 * screenshots, with options for injecting additional content, handling cookies,
 * and configuring various settings.
 *
 * <p>
 * Features include:</p>
 * <ul>
 * <li>Loading HTML content from a URL or file path</li>
 * <li>Injecting CSS, JavaScript, and HTML content</li>
 * <li>Handling cookies</li>
 * <li>Taking single, multiple, or full-page screenshots</li>
 * <li>Configuring WebDriver options such as headless mode, incognito mode, and
 * debugging</li>
 * <li>Setting up network interception for URL modification</li>
 * </ul>
 *
 * <p>
 * Usage example:</p>
 * <pre>{@code
 * HtmlToRaster htmlToRaster = new HtmlToRaster.Builder("file:///path/to/html", "/path/to/output.png")
 *     .width(1280)
 *     .height(720)
 *     .dpi(96)
 *     .isHeadless(true)
 *     .debug(false)
 *     .isIncognito(true)
 *     .timeout(10)
 *     .isMultipleScreenshots(false)
 *     .isLongScreenshot(true)
 *     .build();
 * htmlToRaster.convertToPng();
 * }</pre>
 *
 * <p>
 * Note: Ensure that the necessary WebDriver binaries are available and properly
 * configured.</p>
 *
 * <p>
 * Dependencies:</p>
 * <ul>
 * <li>Selenium WebDriver</li>
 * <li>WebDriverManager</li>
 * <li>ChromeDriver</li>
 * </ul>
 *
 * <p>
 * Author: Saleem</p>
 */
public class HtmlToRaster {

    private WebDriver driver;
    private String urlOrFilePath;
    private String outputPath;
    private int width;
    private int height;
    private int dpi;
    private boolean isHeadless;
    private boolean debug;
    private boolean isIncognito;
    private int timeout;
    private boolean scrollPage;
    private boolean isMultipleScreenshots;
    private String scriptToInject;
    private String cssToInject;
    private String htmlToInject;
    private String currentDomain;
    private String replacementDomain;
    private boolean isLongScreenshot;
    private DevTools devTools;
    private Set<Cookie> cookies;
    private String driverVersion;
    private int[] cropArea;
    private String scaleToFitJs;
    private boolean isFileProcess = false;

    /**
     * Constructs an HtmlToRaster object using the provided Builder.
     *
     * @param builder the Builder object containing the configuration for
     * HtmlToRaster
     */
    public HtmlToRaster(Builder builder) {
        this.urlOrFilePath = builder.urlOrFilePath;

        if (this.urlOrFilePath.startsWith("http://") || this.urlOrFilePath.startsWith("https://")) {
            this.isFileProcess = false;
        } else {
            // Ensure it's a file path
            if (!this.urlOrFilePath.startsWith("file:///")) {
                this.urlOrFilePath = "file:///" + this.urlOrFilePath.replaceFirst("^[./]+", "");
            }
            this.isFileProcess = true;
        }

        this.outputPath = builder.outputPath;
        this.width = builder.width;
        this.height = builder.height;
        this.dpi = builder.dpi;
        this.isHeadless = builder.isHeadless;
        this.debug = builder.debug;
        this.isIncognito = builder.isIncognito;
        this.timeout = builder.timeout;
        this.isMultipleScreenshots = builder.isMultipleScreenshots;
        this.scriptToInject = builder.scriptToInject;
        this.cssToInject = builder.cssToInject;
        this.htmlToInject = builder.htmlToInject;
        this.currentDomain = builder.currentDomain;
        this.replacementDomain = builder.replacementDomain;
        this.cookies = builder.cookies;
        this.isLongScreenshot = builder.isLongScreenshot;
        this.driverVersion = builder.driverVersion;
        this.cropArea = builder.cropArea;
        this.scaleToFitJs = null;

        // ✅ Redirect Java Console Output to Node.js Console
        PrintStream consoleOut = System.out;
        PrintStream consoleErr = System.err;

        System.setOut(new PrintStream(System.out) {
            public void println(String s) {
                super.println("[GTGS-LOG] " + s);
            }
        });

        System.setErr(new PrintStream(System.err) {
            public void println(String s) {
                super.println("[CORE-ERROR] " + s);
            }
        });

        System.out.println("✅ HtmlToRaster Class Initialized!");
    }

    /**
     * Converts the current web page or HTML file to a PNG image.
     *
     * This method initializes a WebDriver, navigates to the specified URL or
     * file path, waits for the page to load, injects any necessary content or
     * scripts, and captures a screenshot of the page. The screenshot can be a
     * single image, a long screenshot, or multiple screenshots depending on the
     * configuration.
     *
     * @return A JSON string indicating the status and message of the operation.
     * The status is true if the image was created successfully, otherwise
     * false. The message provides additional information or error details.
     */
    public String convertToPng() {
        String response = "";
        try {
            this.driver = initializeWebDriver();
            if (!this.isLongScreenshot && !this.isMultipleScreenshots) {
                this.driver.manage().window().setSize(new Dimension((width + 46), (height + 164)));
            } else {
                //window will work in fullscreen mode
            }
            this.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(this.timeout));

            if (this.driver != null) {

                if (this.currentDomain != null && !this.currentDomain.isEmpty() && this.replacementDomain != null && !this.replacementDomain.isEmpty()) {
                    setupNetworkInterception();
                }
                if (this.cookies != null && !this.cookies.isEmpty()) {
                    injectCookies(driver);
                }
                this.driver.get(urlOrFilePath);
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
                wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body")));
                injectContent(driver);
                if (scriptToInject != null && !scriptToInject.isEmpty()) {
                    if (!waitForJavaScriptExecution()) {
                        response = "{\"status\":false,\"msg\":\"JavaScript execution failed. Aborting screenshot.\"}";
                        return response;
                    }
                }
                if (isMultipleScreenshots) {
                    scrollAndCaptureScreenshot(driver);
                } else if (this.isLongScreenshot) {
                    takeFullPageScreenshot(driver, outputPath);
                } else {
                    takeChildScreenshot(driver, outputPath);
                }
                response = "{\"status\":true,\"msg\":\"Image has been created successfully\"}";
            } else {
                System.out.println("Google Chrome driver not found");
            }
        } catch (Exception e) {
            e.printStackTrace(); // Print full error details
            response = "{\"status\":false,\"msg\":\"" + e.getMessage() + "\"}";
        } finally {
            if (this.driver != null) {
                this.driver.quit();
            }
        }
        return response;
    }

    /**
     * Injects cookies into the given WebDriver instance.
     * <p>
     * This method first loads the specified URL or file path to ensure the
     * domain is available before adding the cookies. If the cookies list is not
     * null and not empty, it iterates through the list and adds each cookie to
     * the WebDriver's cookie store.
     * </p>
     *
     * @param driver the WebDriver instance to which the cookies will be added
     */
    private void injectCookies(WebDriver driver) {
        if (cookies != null && !cookies.isEmpty()) {
            driver.get(urlOrFilePath); // Load domain before adding cookies
            for (Cookie cookie : cookies) {
                driver.manage().addCookie(cookie);
            }
        }
    }

    /**
     * Sets up network interception for a ChromeDriver instance. This method
     * enables network interception using Chrome DevTools Protocol and modifies
     * the URL of intercepted requests if they match the current domain.
     *
     * <p>
     * If the driver is not an instance of ChromeDriver, the method returns
     * without doing anything.</p>
     *
     * <p>
     * Network interception is enabled and a listener is added to handle
     * intercepted requests. If the request URL contains the current domain, it
     * is replaced with the replacement domain. The modified URL is then used to
     * continue the intercepted request. If the request URL does not contain the
     * current domain, the request is continued without modification.</p>
     *
     * <p>
     * Note: This method assumes that the fields `driver`, `devTools`,
     * `currentDomain`, and `replacementDomain` are properly initialized
     * elsewhere in the class.</p>
     */
    private void setupNetworkInterception() {
        if (!(driver instanceof ChromeDriver)) {
            return;
        }

        ChromeDriver chromeDriver = (ChromeDriver) driver;
        devTools = chromeDriver.getDevTools();
        devTools.createSession();

        // Enable network interception
        devTools.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));

        devTools.addListener(Network.requestIntercepted(), interceptedRequest -> {
            InterceptionId interceptionId = interceptedRequest.getInterceptionId();
            String requestUrl = interceptedRequest.getRequest().getUrl();

            if (currentDomain != null && requestUrl.contains(currentDomain)) {
                String modifiedUrl = requestUrl.replace(currentDomain, replacementDomain);

                devTools.send(Network.continueInterceptedRequest(
                        interceptionId, // Use InterceptionId
                        Optional.empty(), // No ErrorReason
                        Optional.of(modifiedUrl), // Modify URL
                        Optional.empty(), // No method override
                        Optional.empty(), // No post data override
                        Optional.empty(), // No headers override
                        Optional.empty(), // No custom headers
                        Optional.empty() // No auth challenge response
                ));
            } else {
                devTools.send(Network.continueInterceptedRequest(
                        interceptionId,
                        Optional.empty(),
                        Optional.empty(),
                        Optional.empty(),
                        Optional.empty(),
                        Optional.empty(),
                        Optional.empty(),
                        Optional.empty()
                ));
            }
        });
    }

    /**
     * Waits for the JavaScript execution to complete by checking the value of
     * the `window.isPageReady` variable. This method uses a WebDriverWait to
     * poll the JavaScript condition until it returns true or the timeout is
     * reached.
     *
     * @return true if the JavaScript execution is complete and
     * `window.isPageReady` is true, false if an exception occurs or the timeout
     * is reached.
     */
    private boolean waitForJavaScriptExecution() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
            return wait.until(d -> (Boolean) ((JavascriptExecutor) d).executeScript("return window.isPageReady !== undefined && window.isPageReady;"));
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Injects CSS, JavaScript, and HTML content into the web page loaded in the
     * given WebDriver instance.
     *
     * @param driver the WebDriver instance used to interact with the web page.
     *
     * The method performs the following actions: - If `cssToInject` is not null
     * and not empty, it creates a <style> element, sets its inner HTML to the
     * CSS content, and appends it to the document's head. - If `scriptToInject`
     * is not null and not empty, it creates a <script> element, sets its inner
     * HTML to the JavaScript content, and appends it to the document's body. -
     * If `htmlToInject` is not null and not empty, it appends the HTML content
     * to the document's body.
     */
    private void injectContent(WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;

        if (cssToInject != null && !cssToInject.isEmpty()) {
            js.executeScript("var style = document.createElement('style'); style.innerHTML = arguments[0]; document.head.appendChild(style);", cssToInject);
        }
        if (scriptToInject != null && !scriptToInject.isEmpty()) {
            js.executeScript("var script2 = document.createElement('script'); script2.innerHTML = arguments[0]; document.body.appendChild(script2);", scriptToInject);
        }
        if (htmlToInject != null && !htmlToInject.isEmpty()) {
            js.executeScript("document.body.innerHTML += arguments[0];", htmlToInject);
        }
    }

    private static String getChromeVersion() {
        String command;
        String os = System.getProperty("os.name").toLowerCase();

        if (os.contains("win")) {
            command = "reg query \"HKEY_CURRENT_USER\\Software\\Google\\Chrome\\BLBeacon\" /v version";
        } else if (os.contains("mac")) {
            command = "/Applications/Google\\ Chrome.app/Contents/MacOS/Google\\ Chrome --version";
        } else {
            command = "google-chrome --version"; // For Linux
        }

        try {
            Process process = Runtime.getRuntime().exec(new String[]{"bash", "-c", command});
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                return line.replaceAll("[^0-9.]", ""); // Extract only version numbers
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    private boolean isSameVersion() {
        if (this.driverVersion == null) {
            this.driverVersion = "130.0.6723.58"; // Default fallback version
        }

        if (GlobalProperties.isDebug) {
            System.out.println("Google Driver Version: " + this.driverVersion);
        }

        String chromeVersion = getChromeVersion();

        if (chromeVersion == null) {
            System.out.println("Error: Unable to determine Google Chrome version.");
            return false;
        }

        if (GlobalProperties.isDebug) {
            System.out.println("Google Chrome Version: " + chromeVersion);
        }

        // Compare only the major version
        String driverMajorVersion = this.driverVersion.split("\\.")[0];
        String chromeMajorVersion = chromeVersion.split("\\.")[0];

        if (driverMajorVersion.equals(chromeMajorVersion)) {
            return true;
        } else {
            System.out.println("Mismatch: Chrome Version " + chromeVersion + " and Driver Version " + this.driverVersion);
            return false;
        }
    }

    /**
     * Initializes the WebDriver with ChromeOptions and sets up the
     * ChromeDriver.
     *
     * This method performs the following steps: 1. Creates necessary
     * directories and sets permissions. 2. Configures ChromeOptions with
     * various arguments for ChromeDriver. 3. Sets up WebDriverManager with
     * desired capabilities and driver version. 4. Initializes the ChromeDriver
     * with the configured options.
     *
     * @return WebDriver instance initialized with ChromeDriver.
     * @throws Exception if there is an error during WebDriver initialization.
     */
    private WebDriver initializeWebDriver() {
        try {

            String userDataDir = Paths.get("/tmp/dhtranscoder/.config", "chrome-" + System.currentTimeMillis()).toString();
            String profileDir = "/tmp/dhtranscoder/google-chrome";
            String userCacheDir = "/tmp/dhtranscoder/.cache/google-chrome";
            String userTempDir = "/tmp/dhtranscoder/tmp";
            String userLogDir = "/tmp/dhtranscoder/log";
            // Create the directories and set permissions
            if (GlobalProperties.isDebug) {
                System.out.println("Creating directories...");
            }
            createDirectoriesWithPermissions(userDataDir, profileDir, userCacheDir, userTempDir, userLogDir);
            if (GlobalProperties.isDebug) {
                System.out.println("Directories created.");
            }
            ChromeOptions options = new ChromeOptions();
            options.setBinary("/usr/bin/google-chrome");
            options.addArguments("--remote-allow-origins=*"); // Prevents 403 error
            options.addArguments("--disable-sync");
            options.addArguments("--no-default-browser-check");
            options.addArguments("--no-sandbox");
            options.addArguments("--disable-dev-shm-usage");
            options.addArguments("--disable-setuid-sandbox");
            options.addArguments("--disable-accelerated-2d-canvas");
            options.addArguments("--disable-software-rasterizer");
            options.addArguments("--disable-plugins");
            options.addArguments("--enable-automation");
            options.addArguments("--lang=en-US");
            options.addArguments("--disable-notifications");
            options.addArguments("--disable-logging");
            options.addArguments("--disable-features=IsolateOrigins,site-per-process");
            options.addArguments("--no-first-run");
            options.addArguments("--no-zygote");
            if (this.isLongScreenshot || this.isMultipleScreenshots || width == 0 || height == 0) {
                options.addArguments("--start-fullscreen");
                options.addArguments("--start-maximized");                
            }else{
                options.addArguments("--start-minimized");
                options.addArguments("window-size=" + 0 + "," + 0);
            }
            options.addArguments("--disable-web-security");
            options.addArguments("--allow-running-insecure-content");
            options.addArguments("--ignore-certificate-errors");
            options.addArguments("--disable-gpu");
//            
            options.addArguments("--disable-extensions");
            options.addArguments("--user-data-dir=" + userDataDir);
            options.addArguments("--cache-dir=" + userCacheDir);
            options.addArguments("--tmp-dir=" + userTempDir);
            options.addArguments("--log-path=" + userLogDir);
            if (this.isHeadless) {
                options.addArguments("--headless");
                options.addArguments("--disable-gpu");
            }
            if (this.debug) {
                options.addArguments("--remote-debugging-port=9222"); // Debugging option
            }
            if (this.isIncognito) {
                options.addArguments("--incognito");
            }

            System.out.println("Resetting width & height as provided html file - width: " + width + " height: " + height);

            if (!this.isLongScreenshot && !this.isMultipleScreenshots && width > 0 && height > 0) {
                System.out.println("Inside condition");

                Dimensions sizeUtil = null;
                System.out.println("Inside condition this.isFileProcess: " + this.isFileProcess);
                if (this.isFileProcess) {

                    sizeUtil = HtmlSizeUtil.getBodyDimensionsFromFile(this.urlOrFilePath);
                }

                if (sizeUtil != null && sizeUtil.getWidth() > 0 && sizeUtil.getHeight() > 0) {
                    int originalWidth = sizeUtil.getWidth();
                    int originalHeight = sizeUtil.getHeight();

                    System.out.println("Inside condition originalWidth: " + originalWidth + " originalHeight: " + originalHeight);

                    double originalAspectRatio = (double) originalWidth / originalHeight;
                    double targetAspectRatio = (double) width / height;

                    // If aspect ratios don’t match, adjust dimensions
                    if (Math.abs(originalWidth * height - originalHeight * width) > 1) {
                        if (width > height) {
                            height = (int) (width / originalAspectRatio);
                        } else {
                            width = (int) (height * originalAspectRatio);
                        }
                        System.out.println("Adjusted width & height - width: " + width + " height: " + height);
                    }
                }

                // Enforce max size limit (4000x4000)
                if (width > 4000 || height > 4000) {
                    double scaleFactor = Math.min(4000.0 / width, 4000.0 / height);
                    if (scaleFactor < 1.0) {
                        width = (int) (width * scaleFactor);
                        height = (int) (height * scaleFactor);
                        System.out.println("Resetting width & height as provided values exceeded limits - width: " + width + " height: " + height);
                    }
                }
            } else if (this.isMultipleScreenshots || this.isLongScreenshot) {
                if (width == 0 || height == 0) {
                    width = 1920;
                    height = 1080;
                }
            }

            

            // Setup WebDriverManager
            if (GlobalProperties.isDebug) {
                System.out.println("Setting up WebDriverManager...");
            }
            //WebDriverManager.chromedriver().setup();
            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability(ChromeOptions.CAPABILITY, options);
            this.isSameVersion();
            WebDriverManager.chromedriver()
                    .clearDriverCache()
                    .capabilities(capabilities)
                    .avoidUseChromiumDriverSnap()
                    .cachePath(userCacheDir)
                    .clearResolutionCache()
                    .driverVersion(this.driverVersion)
                    .setup();
            if (GlobalProperties.isDebug) {
                System.out.println("WebDriverManager setup completed.");
            }
            // Initialize ChromeDriver
            if (GlobalProperties.isDebug) {
                System.out.println("Initializing ChromeDriver...");
            }
            this.driver = new ChromeDriver(options);
            this.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            if (GlobalProperties.isDebug) {
                System.out.println("ChromeDriver initialized successfully.");
            }

        } catch (Exception ee) {
            System.out.println("Error initializing WebDriver: " + ee.getMessage());
            ee.printStackTrace();
        }
        return this.driver;
    }

    /**
     * Resizes the given BufferedImage to the specified target width and height.
     *
     * @param image the original BufferedImage to be resized
     * @param targetWidth the desired width of the resized image
     * @param targetHeight the desired height of the resized image
     * @return a new BufferedImage that has been resized to the specified
     * dimensions
     */
    private BufferedImage resizeImage(BufferedImage image, int targetWidth, int targetHeight) {
        // Resize image with the given dimensions
        Image scaledImage = image.getScaledInstance(targetWidth, targetHeight, Image.SCALE_SMOOTH);
        BufferedImage bufferedImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = bufferedImage.createGraphics();
        g2d.drawImage(scaledImage, 0, 0, null);
        g2d.dispose();
        return bufferedImage;

    }

    private BufferedImage resizeImageIfNeeded(BufferedImage originalImage, int targetWidth, int targetHeight) {
        int originalWidth = originalImage.getWidth();
        int originalHeight = originalImage.getHeight();

        // Calculate aspect ratios
        double originalAspectRatio = (double) originalWidth / originalHeight;
        double targetAspectRatio = (double) targetWidth / targetHeight;

        // Check if resizing is needed
        if (Math.abs(originalAspectRatio - targetAspectRatio) < 0.01) {
            return originalImage; // Aspect ratios are nearly the same, no need to resize
        }

        int newWidth, newHeight;

        if (originalAspectRatio > targetAspectRatio) {
            // Original image is wider, scale based on width
            newWidth = targetWidth;
            newHeight = (int) (targetWidth / originalAspectRatio);
        } else {
            // Original image is taller, scale based on height
            newHeight = targetHeight;
            newWidth = (int) (targetHeight * originalAspectRatio);
        }

        // Resize image
        Image tmp = originalImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        BufferedImage resizedImage = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB);

        Graphics2D g2d = resizedImage.createGraphics();
        g2d.drawImage(tmp, 0, 0, null);
        g2d.dispose();

        System.out.println("Resized image to: " + newWidth + "x" + newHeight);
        return resizedImage;
    }

    /**
     * Resizes the given BufferedImage to the specified target width and height.
     *
     * @param image the original BufferedImage to be resized
     * @param targetWidth the desired width of the resized image
     * @param targetHeight the desired height of the resized image
     * @return a new BufferedImage that has been resized to the specified
     * dimensions
     */
    private BufferedImage cropImage(BufferedImage image, int targetWidth, int targetHeight) {

        image = image.getSubimage(0, 0, targetWidth, targetHeight);

        int originalWidth = image.getWidth();
        int originalHeight = image.getHeight();

        double originalAspectRatio = (double) originalWidth / originalHeight;
        double targetAspectRatio = (double) targetWidth / targetHeight;
        int newWidth = targetWidth;
        int newHeight = targetHeight;

        // If the aspect ratios don't match, adjust the target width or height
        if (!this.isLongScreenshot && !this.isMultipleScreenshots) {
            if (Math.abs(originalAspectRatio - targetAspectRatio) > 0.01) { // Tolerance for floating point errors
                if (targetWidth > targetHeight) {
                    newWidth = targetWidth;
                    newHeight = (int) (newWidth / originalAspectRatio);
                } else {
                    newHeight = targetHeight;
                    newWidth = (int) (newHeight * originalAspectRatio);
                }
            }
        }
        // Resize the image
        Image scaledImage = image.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        BufferedImage bufferedImage = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = bufferedImage.createGraphics();
        g2d.drawImage(scaledImage, 0, 0, null);
        g2d.dispose();

        return bufferedImage;
    }

    /**
     * Creates directories with the specified permissions.
     *
     * @param directories the directories to be created
     * @throws IOException if an I/O error occurs or the permissions cannot be
     * set
     */
    private void createDirectoriesWithPermissions(String... directories) throws IOException {
        Set<PosixFilePermission> perms = PosixFilePermissions.fromString("rwxrwxrwx");
        for (String dir : directories) {
            Files.createDirectories(Paths.get(dir));
            Files.setPosixFilePermissions(Paths.get(dir), perms);
        }
    }

    /**
     * Closes the web driver if it is not null. This method will quit the web
     * driver, releasing any resources it holds.
     */
    public void close() {
        if (this.driver != null) {
            this.driver.quit();
        }
    }

    private void takeChildScreenshot(WebDriver driver, String outputPath) {
        try {
            if (!(driver instanceof ChromeDriver)) {
                System.out.println("This feature requires ChromeDriver.");
                return;
            }

            ChromeDriver chromeDriver = (ChromeDriver) driver;
            DevTools devTools = chromeDriver.getDevTools();
            devTools.createSession();

            JavascriptExecutor js = (JavascriptExecutor) driver;

            // Ensure the page is fully loaded
//            Thread.sleep(500);

            // Force scroll to top
            js.executeScript("window.scrollTo(0, 0);");

            // Get the first child element or wrap all children into a div
            String script = "var body = document.body; "
                    + "var children = Array.from(body.children); "
                    + "if (children.length === 1) { return children[0]; } "
                    + "else { "
                    + "   var wrapper = document.createElement('div'); "
                    + "   wrapper.style.position = 'absolute'; "
                    + "   wrapper.style.left = '0'; "
                    + "   wrapper.style.top = '0'; "
                    + "   wrapper.style.width = 'fit-content'; "
                    + "   wrapper.style.height = 'fit-content'; "
                    + "   wrapper.style.overflow = 'hidden'; "
                    + // Prevent scrolling
                    "   children.forEach(child => wrapper.appendChild(child)); "
                    + "   body.appendChild(wrapper); "
                    + "   return wrapper; "
                    + "}";

            WebElement targetElement = (WebElement) js.executeScript(script);
            // Ensure full rendering before measuring dimensions
//            Thread.sleep(500);
            // Get the exact dimensions of the target element
            long elementWidth = ((Number) js.executeScript("return arguments[0].getBoundingClientRect().width;", targetElement)).longValue();
            long elementHeight = ((Number) js.executeScript("return arguments[0].getBoundingClientRect().height;", targetElement)).longValue();

            // Ensure the element is fully visible before capturing
            js.executeScript("arguments[0].scrollIntoView(true);", targetElement);

            // Set viewport to match the target element size exactly
            Optional<Page.CaptureScreenshotFormat> format = Optional.of(Page.CaptureScreenshotFormat.PNG);
            Optional<Viewport> viewport = Optional.of(new Viewport(0, 0, (double) elementWidth, (double) elementHeight, 1.0));
            Optional<Integer> formatDpi = Optional.ofNullable(null);

            // Capture the screenshot
            String base64Screenshot = devTools.send(
                    Page.captureScreenshot(
                            format,
                            formatDpi,
                            viewport,
                            Optional.of(true),
                            Optional.of(true),
                            Optional.of(false)
                    )
            );

            // Convert Base64 string to byte array and decode image
            byte[] screenshotBytes = Base64.getDecoder().decode(base64Screenshot);
            BufferedImage capturedImage = ImageIO.read(new ByteArrayInputStream(screenshotBytes));

            System.out.println("capturedImage: " + width+", "+ height);
            // Resize if aspect ratio is different
            BufferedImage resizedImage = resizeImageIfNeeded(capturedImage, width, height);

            // Save the final image
            Path outputFilePath = Paths.get(outputPath);
            Files.createDirectories(outputFilePath.getParent());
            ImageIO.write(resizedImage, "png", new File(outputFilePath.toString()));

            if (GlobalProperties.isDebug) {
                System.out.println("Screenshot saved successfully: " + outputFilePath);
            }

            // Restore original structure
            js.executeScript("if (document.getElementById('tempWrapper')) {"
                    + "    var wrapper = document.getElementById('tempWrapper');"
                    + "    while (wrapper.firstChild) document.body.appendChild(wrapper.firstChild);"
                    + "    wrapper.remove();"
                    + "}");

        } catch (Exception e) {
            System.out.println("Error taking child screenshot: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Captures a screenshot of the current page displayed by the WebDriver,
     * resizes it, and saves it to the specified file path.
     *
     * @param driver the WebDriver instance used to capture the screenshot
     * @param filePath the path where the screenshot will be saved
     * @throws Exception if an error occurs during the screenshot capture or
     * file writing process
     */
    private void takeScreenshot(WebDriver driver, String filePath) throws Exception {
        try {
            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            BufferedImage image = ImageIO.read(screenshot);
            BufferedImage resizedImage = resizeImage(image, width, height);
            ImageIO.write(resizedImage, "PNG", new File(filePath));
        } catch (IOException e) {
            System.err.println("Error capturing screenshot: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Takes a full-page screenshot of the current page in the Chrome browser
     * and saves it to the specified output path. This method uses Chrome
     * DevTools Protocol to capture the screenshot.
     *
     * @param driver The WebDriver instance, which must be an instance of
     * ChromeDriver.
     * @param outputPath The file path where the screenshot will be saved.
     * @throws IllegalArgumentException if the provided WebDriver is not an
     * instance of ChromeDriver.
     * @throws IOException if an I/O error occurs while saving the screenshot.
     * @throws InterruptedException if the thread is interrupted while waiting
     * for the page to render.
     * @throws WebDriverException if an error occurs while interacting with the
     * WebDriver.
     */
    private void takeFullPageScreenshot(WebDriver driver, String outputPath) {
        try {
            if (!(driver instanceof ChromeDriver)) {
                System.out.println("This feature requires ChromeDriver.");
                return;
            }

            ChromeDriver chromeDriver = (ChromeDriver) driver;
            DevTools devTools = chromeDriver.getDevTools();
            devTools.createSession();

            JavascriptExecutor js = (JavascriptExecutor) driver;

            // Ensure the page is fully loaded
            Thread.sleep(500); // Delay for full render

            // Force scroll to top
            js.executeScript("window.scrollTo(0, 0);");

            // Get actual viewport size and content size
            long fullHeight = (long) js.executeScript(
                    "return Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);"
            );
            long fullWidth = (long) js.executeScript(
                    "return Math.max(document.documentElement.scrollWidth, document.body.scrollWidth);"
            );

            // Force correct dimensions
            js.executeScript("document.documentElement.style.overflow = 'hidden';");
            js.executeScript("document.body.style.margin = '0'; document.body.style.padding = '0';");
            js.executeScript("document.body.style.width = arguments[0] + 'px';", fullWidth);
            js.executeScript("document.body.style.height = arguments[0] + 'px';", fullHeight);

            // Ensure no unwanted scaling
            js.executeScript("document.body.style.transform = 'none';");

            // Wait for changes to take effect
            Thread.sleep(500);

            // Set viewport to capture full content
            Optional<Page.CaptureScreenshotFormat> format = Optional.of(Page.CaptureScreenshotFormat.PNG);
            Optional<Viewport> viewport = Optional.of(new Viewport(0, 0, (double) fullWidth, (double) fullHeight, 1.0));
            Optional<Integer> formatDpi = Optional.ofNullable(this.dpi); // Prevents NullPointerException
            // Capture the screenshot using Chrome DevTools Protocol
            String base64Screenshot = devTools.send(
                    Page.captureScreenshot(
                            format,
                            formatDpi,
                            viewport,
                            Optional.of(true),
                            Optional.of(true),
                            Optional.of(false)
                    )
            );

            // Convert Base64 string to byte array and save
            byte[] screenshot = Base64.getDecoder().decode(base64Screenshot);
            Path outputFilePath = Paths.get(outputPath);
            Files.createDirectories(outputFilePath.getParent());
            Files.write(outputFilePath, screenshot);
            if (GlobalProperties.isDebug) {
                System.out.println("Screenshot saved successfully: " + outputFilePath);
            }

            // Restore original styles
            js.executeScript("document.documentElement.style.overflow = '';");
            js.executeScript("document.body.style.margin = ''; document.body.style.padding = '';");
            js.executeScript("document.body.style.width = ''; document.body.style.height = '';");

        } catch (Exception e) {
            System.out.println("Error taking full-page screenshot: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Scrolls through the webpage and captures screenshots at each scroll
     * position.
     *
     * @param driver the WebDriver instance used to interact with the web page
     * @throws Exception if an error occurs during scrolling or capturing
     * screenshots
     *
     * This method calculates the total height of the web page and divides it by
     * the viewport height to determine the number of scrolls required. It then
     * scrolls the page in increments of the viewport height, waits for the page
     * to settle, and captures a screenshot at each scroll position. The
     * screenshots are saved with filenames indicating their respective scroll
     * positions.
     */
    private void scrollAndCaptureScreenshot(WebDriver driver) throws Exception {
        try {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            Long totalHeight = (Long) js.executeScript("return document.body.scrollHeight");
            int viewportHeight = height; // Set viewport height properly
            int numOfScrolls = (int) Math.ceil(totalHeight / (double) viewportHeight);

            for (int i = 1; i < numOfScrolls; i++) {
                js.executeScript("window.scrollTo(0, " + (i * viewportHeight) + ");");

                // Wait for the scroll to settle
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
                wait.until(ExpectedConditions.jsReturnsValue("return document.readyState === 'complete'"));

                // Take screenshot only after each scroll
                String filePath = outputPath.replace(".png", "_part" + (i) + ".png");
                takeScreenshot(driver, filePath);
                Thread.sleep(100);
            }

        } catch (Exception e) {
            System.out.println("Error scrolling and capturing screenshot: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Builder class for constructing instances of HtmlToRaster with various
     * configuration options.
     */
    public static class Builder {

        private String urlOrFilePath;
        private String outputPath;
        private int width = 0; // Default value
        private int height = 0; // Default value
        private int dpi = 300; // Default value
        private boolean isHeadless = true; // Default value
        private boolean debug = false; // Default value
        private boolean isIncognito = true; // Default value
        private int timeout = 5; // Default value (seconds)        
        private boolean isMultipleScreenshots = false; // Default value
        private boolean isLongScreenshot = false;
        private String scriptToInject = ""; // Default value
        private String cssToInject = ""; // Default value
        private String htmlToInject = ""; // Default value
        private String currentDomain = null;
        private String replacementDomain = null;
        private Set<Cookie> cookies = null;
        private String driverVersion = null;
        private int[] cropArea = null;

        /**
         * Constructs a new Builder
         */
        public Builder() {
        }

        /**
         * Sets the CSS to be injected into the HTML.
         *
         * @param urlOrFilePath the CSS string to be injected
         * @return the Builder instance for method chaining
         */
        public Builder urlOrFilePath(String urlOrFilePath) {
            this.urlOrFilePath = urlOrFilePath;
            return this;
        }

        /**
         * Sets the CSS to be injected into the HTML.
         *
         * @param outputPath the CSS string to be injected
         * @return the Builder instance for method chaining
         */
        public Builder outputPath(String outputPath) {
            this.outputPath = outputPath;
            return this;
        }

        /**
         * Sets the width for the builder.
         *
         * @param width the width to set
         * @return the builder instance with the updated width
         */
        public Builder width(int width) {
            this.width = width;
            return this;
        }

        /**
         * Sets the height for the builder.
         *
         * @param height the height to set
         * @return the updated Builder instance
         */
        public Builder height(int height) {
            this.height = height;
            return this;
        }

        /**
         * Sets the DPI (dots per inch) for the rasterization process.
         *
         * @param dpi the desired DPI value
         * @return the Builder instance for method chaining
         */
        public Builder dpi(int dpi) {
            this.dpi = dpi;
            return this;
        }

        /**
         * Sets the Headless mode for the builder.
         *
         * @param isHeadless a boolean indicating whether to enable Headless
         * mode
         * @return the Builder instance with the updated Headless mode
         */
        public Builder isHeadless(boolean isHeadless) {
            this.isHeadless = isHeadless;
            return this;
        }

        /**
         * Sets the debug mode for the builder.
         *
         * @param debug a boolean indicating whether to enable debug mode
         * @return the current Builder instance for method chaining
         */
        public Builder debug(boolean debug) {
            this.debug = debug;
            return this;
        }

        /**
         * Sets the Incognito mode for the builder.
         *
         * @param isIncognito a boolean indicating whether to enable Incognito
         * mode
         * @return the Builder instance with the updated Incognito mode
         */
        public Builder isIncognito(boolean isIncognito) {
            this.isIncognito = isIncognito;
            return this;
        }

        /**
         * Sets the timeout value for the operation.
         *
         * @param timeout the timeout value in milliseconds
         * @return the Builder instance for method chaining
         */
        public Builder timeout(int timeout) {
            this.timeout = timeout;
            return this;
        }

        /**
         * Sets the flag to enable or disable multiple screenshots.
         *
         * @param isMultipleScreenshots a boolean indicating whether multiple
         * screenshots should be taken.
         * @return the Builder instance for method chaining.
         */
        public Builder isMultipleScreenshots(boolean isMultipleScreenshots) {
            this.isMultipleScreenshots = isMultipleScreenshots;
            if (this.isLongScreenshot) {
                this.isMultipleScreenshots = false;
            }
            if ((this.isMultipleScreenshots) && (this.width > 1920 || this.height > 1080)) {
                throw new IllegalArgumentException(" In Multiple Screenshots Mode, you can not set width more than 1920 and height more than 1080");
            }
            if ((this.isLongScreenshot) && this.width > 1920) {
                throw new IllegalArgumentException(" In Long Screenshots Mode, you can not set width more than 1920");
            }
            return this;
        }

        /**
         * Sets the flag indicating whether the screenshot should be a long
         * screenshot.
         *
         * @param isLongScreenshot true if the screenshot should be a long
         * screenshot, false otherwise
         * @return the Builder instance for method chaining
         */
        public Builder isLongScreenshot(boolean isLongScreenshot) {
            this.isLongScreenshot = isLongScreenshot;
            if (this.isLongScreenshot) {
                this.isMultipleScreenshots = false;
            }
            if ((this.isMultipleScreenshots) && (this.width > 1920 || this.height > 1080)) {
                throw new IllegalArgumentException(" In Multiple Screenshots Mode, you can not set width more than 1920 and height more than 1080");
            }
            if ((this.isLongScreenshot) && this.width > 1920) {
                throw new IllegalArgumentException(" In Long Screenshots Mode, you can not set width more than 1920");
            }

            return this;
        }

        /**
         * Sets the script to be injected into the HTML.
         *
         * @param scriptToInject the JavaScript code to be injected
         * @return the Builder instance for method chaining
         */
        public Builder scriptToInject(String scriptToInject) {
            this.scriptToInject = scriptToInject;
            return this;
        }

        /**
         * Sets the CSS to be injected into the HTML.
         *
         * @param cssToInject the CSS string to be injected
         * @return the Builder instance for method chaining
         */
        public Builder cssToInject(String cssToInject) {
            this.cssToInject = cssToInject;
            return this;
        }

        /**
         * Sets the HTML content to be injected.
         *
         * @param htmlToInject the HTML content to inject
         * @return the Builder instance for method chaining
         */
        public Builder htmlToInject(String htmlToInject) {
            this.htmlToInject = htmlToInject;
            return this;
        }

        /**
         * Sets the current domain for the builder.
         *
         * @param currentDomain the domain to set
         * @return the builder instance with the updated current domain
         */
        public Builder currentDomain(String currentDomain) {
            this.currentDomain = currentDomain;
            return this;
        }

        /**
         * Sets the replacement domain.
         *
         * @param replacementDomain the domain to replace the current one
         * @return the Builder instance for method chaining
         */
        public Builder replacementDomain(String replacementDomain) {
            this.replacementDomain = replacementDomain;
            return this;
        }

        /**
         * Sets the cookies for the Builder.
         *
         * @param cookies a Set of Cookie objects to be used.
         * @return the Builder instance with the updated cookies.
         */
        public Builder cookies(Set<Cookie> cookies) {
            this.cookies = cookies;
            return this;
        }

        /**
         * Sets the driverVersion for the Builder.
         *
         * @param driverVersion a Set of driver version objects to be used.
         * @return the Builder instance with the updated driverVersion.
         */
        public Builder driverVersion(String driverVersion) {
            this.driverVersion = driverVersion;
            return this;
        }

        public Builder cropArea(String cropObject) {
            if (cropObject == null || cropObject.isEmpty()) {
                throw new IllegalArgumentException("Crop area string is null or empty.");
            }
            // Regex to match "x,y,width,height" format with only numbers
            if (!cropObject.matches("^\\d+,\\d+,\\d+,\\d+$")) {
                throw new IllegalArgumentException("Invalid crop area format. Expected 'x,y,width,height'.");
            }
            // Split the string and parse values
            String[] parts = cropObject.split(",");
            int orgX = Integer.parseInt(parts[0].trim());
            int orgY = Integer.parseInt(parts[1].trim());
            int cpWidth = Integer.parseInt(parts[2].trim());
            int cpHeight = Integer.parseInt(parts[3].trim());
            // Ensure width and height are greater than 0
            if (cpWidth <= 0 || cpHeight <= 0) {
                throw new IllegalArgumentException("Width and height must be greater than zero.");
            }
            this.cropArea = new int[]{orgX, orgY, cpWidth, cpHeight};
            return this;
        }

        /**
         * Builds and returns a new instance of HtmlToRaster using the current
         * state of this builder.
         *
         * @return a new HtmlToRaster instance
         */
        public HtmlToRaster build() {
            return new HtmlToRaster(this);
        }
    }

    public static void main(String[] args) {
        try {

            HtmlToRaster htmlToRaster = new HtmlToRaster.Builder()
                    .urlOrFilePath("file:////home/saleem/Documents/Saleem/workspace/JavaProjects/html/sample.html")
                    //.urlOrFilePath("file:///home/saleem/Documents/JavaProjects/html/index.html")
                    .outputPath("/home/saleem/Documents/Saleem/workspace/JavaProjects/html/output/output_sample.png")
                    .width(2000)
                    .height(1000)
                    .dpi(96)
                    .isHeadless(false)
                    .debug(false)
                    .isIncognito(true)
                    .timeout(10)
                    .isMultipleScreenshots(false)
                    .isLongScreenshot(false)
                    .driverVersion("130.0.6723.58")
                    .build();
            //Make sure this method exists in HtmlToRaster
            htmlToRaster.convertToPng();
            if (GlobalProperties.isDebug) {
                System.out.println("Screenshot captured successfully.");
            }
        } catch (Exception e) {
            System.out.println("Error in main method: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
