/*
 * The MIT License
 * Copyright (c) 2024-2025 Elite India
 *
 * Author: Saleem Ahmad
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.elite.india.sa.eigc;

import com.elite.india.sa.Dimensions;
import com.elite.india.sa.GlobalProperties;
import com.elite.india.sa.HtmlToRaster;
import com.elite.india.sa.RasterToRaster;
import com.elite.india.sa.RasterToSvg;
import com.elite.india.sa.RasterToVector;
import com.elite.india.sa.SvgToRaster;
import com.elite.india.sa.SvgToVector;
import com.elite.india.sa.thirdparty.InkscapeCommand;
import com.elite.india.sa.thirdparty.InkscapeCommandCreator;
import com.elite.india.sa.thirdparty.InkscapeOptions;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author saleem
 */
public class Eigc {

//    static {
//        System.loadLibrary("Eigc"); // Load the native library
//    }
    public Eigc() {

        // ✅ Redirect Java Console Output to Node.js Console
        PrintStream consoleOut = System.out;
        PrintStream consoleErr = System.err;

        System.setOut(new PrintStream(System.out) {
            public void println(String s) {
                super.println("[GTGS-LOG] " + s);
            }
        });

        System.setErr(new PrintStream(System.err) {
            public void println(String s) {
                super.println("[CORE-ERROR] " + s);
            }
        });

        System.out.println("✅ EIGC Class Initialized!");

    }

    /**
     * Extracts image formats from a comma-separated string.
     *
     * @param formats A comma-separated string containing image formats. Must
     * not be null or empty.
     * @return An array of strings, each representing an image format.
     * @throws IllegalArgumentException if the formats string is null or empty.
     */
    private String[] extractImageFormats(String formats) {
        if (formats == null || formats.isEmpty()) {
            throw new IllegalArgumentException("Formats string cannot be null or empty");
        }
        return formats.split(",");
    }

    private String prepareResult(String serviceResponse) {
        return (serviceResponse != null && !serviceResponse.isEmpty() ? serviceResponse.toString() : "{\"status\":false,\"msg\":\"something is not right\"}");
    }

    /**
     * Checks if the given formats string contains multiple formats separated by
     * commas.
     *
     * @param formats the string containing format(s) to be checked
     * @return true if the formats string contains multiple formats separated by
     * commas, false otherwise
     * @throws IllegalArgumentException if the formats string is null or empty
     */
    private boolean isMultipleFormats(String formats) {
        if (formats == null || formats.isEmpty()) {
            throw new IllegalArgumentException("Formats string cannot be null or empty");
        }
        return formats.contains(",");
    }

    /**
     * Returns the name of the file without its extension from the given file
     * path.
     *
     * @param filePath the path of the file
     * @return the name of the file without its extension
     * @throws IllegalArgumentException if the file path is null or empty
     */
    private String getFileNameWithoutExtension(String filePath) {
        if (filePath == null || filePath.isEmpty()) {
            throw new IllegalArgumentException("File path cannot be null or empty");
        }
        File file = new File(filePath);
        String fileName = file.getName();
        int dotIndex = fileName.lastIndexOf('.');
        return (dotIndex == -1) ? fileName : fileName.substring(0, dotIndex);
    }

    /**
     * Returns the file path without its extension.
     * <p>
     * If the path refers to a directory (and exists as one), an
     * IllegalArgumentException is thrown.
     *
     * @param filePath the full file path (e.g., "/home/etc/image.png")
     * @return the file path without the extension (e.g., "/home/etc/image")
     * @throws IllegalArgumentException if filePath is null or refers to a
     * directory.
     */
    public String getFilePathWithoutExtension(String filePath) {
        if (filePath == null) {
            throw new IllegalArgumentException("File path cannot be null");
        }

        File file = new File(filePath);
        // Check if the file exists and is a directory.
        if (file.exists() && file.isDirectory()) {
            throw new IllegalArgumentException("Provided path is a directory: " + filePath);
        }

        // Find the last dot and the last file separator
        int dotIndex = filePath.lastIndexOf('.');
        int separatorIndex = Math.max(filePath.lastIndexOf('/'), filePath.lastIndexOf('\\'));

        // Remove extension only if the dot comes after the last separator
        if (dotIndex > separatorIndex) {
            return filePath.substring(0, dotIndex);
        }
        return filePath;
    }

    /**
     * Returns the directory path of a given file path.
     *
     * @param filePath the full file path (e.g. "/home/etc/image.png")
     * @return the directory part of the file path (e.g. "/home/etc")
     * @throws IllegalArgumentException if filePath is null or if no parent
     * directory is found.
     */
    public static String getDirectoryPath(String filePath) {
        if (filePath == null) {
            throw new IllegalArgumentException("File path cannot be null.");
        }

        File file = new File(filePath);
        String parent = file.getParent();
        if (parent == null) {
            throw new IllegalArgumentException("No parent directory found for " + filePath);
        }
        return parent;
    }

    /**
     * Returns the parent directory path of the given file path.
     *
     * @param filePath the path of the file for which the parent directory path
     * is to be retrieved
     * @return the parent directory path of the given file path
     * @throws IllegalArgumentException if the file path is null, empty, or if
     * the parent directory does not exist
     */
    private String getParentDirectoryPath(String filePath) {
        if (filePath == null || filePath.isEmpty()) {
            throw new IllegalArgumentException("File path cannot be null or empty");
        }
        File file = new File(filePath);
        String parentPath = file.getParent();
        if (parentPath == null) {
            throw new IllegalArgumentException("Parent directory does not exist");
        }
        return parentPath;
    }

    /**
     * Creates a directory if it does not already exist.
     *
     * @param directoryPath the path of the directory to create
     * @throws IllegalArgumentException if the directory path is null or empty
     * @throws IOException if the directory could not be created
     */
    private void createDirectoryIfNotExists(String directoryPath) throws IOException {
        if (directoryPath == null || directoryPath.isEmpty()) {
            throw new IllegalArgumentException("Directory path cannot be null or empty");
        }
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            if (!directory.mkdirs()) {
                throw new IOException("Failed to create directory: " + directoryPath);
            }
        }
    }

    /**
     * Retrieves the default dimensions (width and height) of an SVG file. If
     * the SVG file contains width and height attributes, those values are used.
     * If the width and height attributes are in percentage or not present, the
     * viewBox attribute is used as a fallback. If neither width/height nor
     * viewBox attributes are present or valid, default dimensions of 800x600
     * are used.
     *
     * @param svgFilePath the file path to the SVG file
     * @return a Dimensions object containing the width and height of the SVG
     */
    private Dimensions getDefaultSVGDimensions(String svgFilePath) {
        int defaultWidth = 800;
        int defaultHeight = 600;
        int width = defaultWidth;
        int height = defaultHeight;

        try {
            File file = new File(svgFilePath);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(file);
            Element svgElement = doc.getDocumentElement();

            // Extract width and height attributes
            String widthAttr = svgElement.getAttribute("width");
            String heightAttr = svgElement.getAttribute("height");

            boolean useViewBox = false;

            if (!widthAttr.isEmpty() && !heightAttr.isEmpty()) {
                if (widthAttr.contains("%") || heightAttr.contains("%")) {
                    // If width or height is in %, ignore it
                    useViewBox = true;
                } else {
                    width = this.convertToPixels(widthAttr);
                    height = this.convertToPixels(heightAttr);
                }
            } else {
                useViewBox = true;
            }

            // Check viewBox attribute as fallback
            if (useViewBox) {
                String viewBox = svgElement.getAttribute("viewBox");
                if (!viewBox.isEmpty()) {
                    String[] values = viewBox.split("\\s+");
                    if (values.length == 4) {
                        width = (int) Float.parseFloat(values[2]);
                        height = (int) Float.parseFloat(values[3]);
                    }
                }
            }

            // Ensure valid dimensions
            if (width <= 0) {
                width = defaultWidth;
            }
            if (height <= 0) {
                height = defaultHeight;
            }

        } catch (Exception e) {
            System.out.println("Error parsing SVG: " + e.getMessage());
        }

        return new Dimensions(width, height);
    }

    private Dimensions getImageDimensions(String imagePath) {
        File imageFile = new File(imagePath);
        try {
            BufferedImage image = ImageIO.read(imageFile);
            if (image != null) {
                return new Dimensions(image.getWidth(), image.getHeight());
            } else {
                throw new IOException("Unsupported image format or corrupted file.");
            }
        } catch (IOException e) {
            System.out.println("Error reading image: " + e.getMessage());
            return new Dimensions(640, 480);
        }
    }

    /**
     * Converts a given string value representing a measurement to pixels. The
     * input string can be in various units such as inches (in), centimeters
     * (cm), millimeters (mm), points (pt), picas (pc), or pixels (numeric
     * only).
     *
     * @param value the string value representing the measurement to be
     * converted. It can be in the format of "10in", "5cm", "20mm", "15pt",
     * "2pc", or "100". If the value is null or empty, the method returns 0.
     * @return the equivalent measurement in pixels as an integer. If the
     * conversion fails due to a NumberFormatException, the method returns 0.
     */
    private int convertToPixels(String value) {
        if (value == null || value.isEmpty()) {
            return 0;
        }

        value = value.trim().toLowerCase();
        double pixels = 0;

        try {
            if (value.endsWith("in")) {  // Inches → Pixels
                pixels = Double.parseDouble(value.replace("in", "").trim()) * 96;
            } else if (value.endsWith("cm")) {  // Centimeters → Pixels
                pixels = Double.parseDouble(value.replace("cm", "").trim()) * 37.7952755906;
            } else if (value.endsWith("mm")) {  // Millimeters → Pixels
                pixels = Double.parseDouble(value.replace("mm", "").trim()) * 3.77952755906;
            } else if (value.endsWith("pt")) {  // Points → Pixels
                pixels = Double.parseDouble(value.replace("pt", "").trim()) * 1.3333;
            } else if (value.endsWith("pc")) {  // Picas → Pixels
                pixels = Double.parseDouble(value.replace("pc", "").trim()) * 16;
            } else {  // Assume it's already in pixels (numeric only)
                pixels = Double.parseDouble(value.replaceAll("[^0-9.]", ""));
            }
        } catch (NumberFormatException e) {
            System.out.println("Error converting value to pixels: " + value);
            return 0; // Return 0 to indicate failure
        }

        return (int) Math.round(pixels);
    }

    private String sanitize(String value) {
        return (value != null && value.equalsIgnoreCase("null")) ? null : value;
    }

    private Integer sanitizeInteger(String value) {
        return (value != null && !value.equalsIgnoreCase("null")) ? Integer.parseInt(value) : 0;
    }

    private Double sanitizeDouble(String value) {
        return (value != null && !value.equalsIgnoreCase("null")) ? Double.parseDouble(value) : 1.0;
    }

    private Float sanitizeFloat(String value) {
        return (value != null && !value.equalsIgnoreCase("null")) ? Float.parseFloat(value) : 1.0f;
    }

    private Boolean sanitizeBoolean(String value) {
        return (value != null && !value.equalsIgnoreCase("null") && value.equalsIgnoreCase("true")) ? true : false;
    }

    public String htmlToRaster(
            String input,
            String output,
            String width,//Integer
            String height,//Integer
            String dpi,//Integer
            String isHeadless,//Boolean
            String isIncognito,//Boolean
            String isMultiScreen,//Boolean
            String isLongScreen,//Boolean
            String currentDomain,
            String replacementDomain,
            String scriptToInject,
            String cssToInject,
            String htmlToInject,
            String timeout,//Integer
            String isDebug,//Boolean
            String googleChromeDriverVersion,
            String cropArea
    ) {
        String serviceResponse = null;
        try {
            input = sanitize(input);
            output = sanitize(output);
            width = sanitize(width);
            height = sanitize(height);
            dpi = sanitize(dpi);
            isHeadless = sanitize(isHeadless);
            isIncognito = sanitize(isIncognito);
            isMultiScreen = sanitize(isMultiScreen);
            isLongScreen = sanitize(isLongScreen);
            currentDomain = sanitize(currentDomain);
            replacementDomain = sanitize(replacementDomain);
            scriptToInject = sanitize(scriptToInject);
            cssToInject = sanitize(cssToInject);
            htmlToInject = sanitize(htmlToInject);
            timeout = sanitize(timeout);
            isDebug = sanitize(isDebug);
            googleChromeDriverVersion = sanitize(googleChromeDriverVersion);
            cropArea = sanitize(cropArea);

            if (input == null || input.isEmpty()) {
                throw new IllegalArgumentException("Input file or URL is required");
            }
            if (output == null || output.isEmpty()) {
                throw new IllegalArgumentException("Output file path is required");
            }

            if (isLongScreen != null && !isLongScreen.isEmpty() && isLongScreen.equalsIgnoreCase("true")) {
                isMultiScreen = null;
            }

            HtmlToRaster.Builder builder = new HtmlToRaster.Builder()
                    .urlOrFilePath(input)
                    .outputPath(output)
                    .width((width != null && !width.isEmpty()) ? Integer.parseInt(width) : 1280)
                    .height((height != null && !height.isEmpty()) ? Integer.parseInt(height) : 720)
                    .dpi((dpi != null && !dpi.isEmpty()) ? Integer.parseInt(dpi) : 96)
                    .isHeadless((isHeadless != null && !isHeadless.isEmpty() && isHeadless.equalsIgnoreCase("true")) ? true : false)
                    .isIncognito((isIncognito != null && !isIncognito.isEmpty() && isIncognito.equalsIgnoreCase("true")) ? true : false)
                    .isMultipleScreenshots((isMultiScreen != null && !isMultiScreen.isEmpty() && isMultiScreen.equalsIgnoreCase("true")) ? true : false)
                    .isLongScreenshot((isLongScreen != null && !isLongScreen.isEmpty() && isLongScreen.equalsIgnoreCase("true")) ? true : false)
                    .timeout((timeout != null && !timeout.isEmpty()) ? Integer.parseInt(timeout) : 5)
                    .debug((isDebug != null && !isDebug.isEmpty() && isDebug.equalsIgnoreCase("true")) ? true : false)
                    .driverVersion(googleChromeDriverVersion != null ? googleChromeDriverVersion : "132.0.6834.159");

            if (currentDomain != null && replacementDomain != null) {
                builder.currentDomain(currentDomain).replacementDomain(replacementDomain);
            }
            if (scriptToInject != null) {
                builder.scriptToInject(scriptToInject);
            }
            if (cssToInject != null) {
                builder.cssToInject(cssToInject);
            }
            if (htmlToInject != null) {
                builder.htmlToInject(htmlToInject);
            }
            if (cropArea != null && !cropArea.isEmpty()) {
                builder.cropArea(cropArea);
            }

            serviceResponse = new HtmlToRaster(builder).convertToPng();
        } catch (Exception e) {
            serviceResponse = "{\"status\":false,\"msg\":\"" + e.getMessage() + "\"}";
        }
        return this.prepareResult(serviceResponse);
    }

    public String rasterToRaster(
            String input,
            String output,
            String width,//Integer
            String height,//Integer
            String dpi,//Integer
            String quality,
            String format
    ) {
        input = sanitize(input);
        output = sanitize(output);
        width = sanitize(width);
        height = sanitize(height);
        dpi = sanitize(dpi);
        quality = sanitize(quality);
        format = sanitize(format);

        String serviceResponse = null;
        try {

            if (input == null || input.isEmpty()) {
                throw new IllegalArgumentException("Input file is required");
            }
            if (output == null || output.isEmpty()) {
                throw new IllegalArgumentException("Output file path is required");
            }

            Dimensions size = this.getImageDimensions(input);

//            System.out.println("adding to builder:");
            if (size != null && size.getHeight() > 0 && size.getHeight() > 0) {
                if (width != null && !width.isEmpty() && (height == null || height.isEmpty())) {
                    //then find height
                    height = (Integer.parseInt(width) * size.getHeight()) / (size.getWidth()) + "";
                } else if (height != null && !height.isEmpty() && (width == null || width.isEmpty())) {
                    //then find width
                    width = (Integer.parseInt(height) * size.getWidth()) / (size.getHeight()) + "";
                }
            }

            RasterToRaster.Builder builder = new RasterToRaster.Builder()
                    .inputFile(input)
                    .outputFile(output)
                    .width((width != null && !width.isEmpty()) ? Integer.parseInt(width) : size.getWidth())
                    .height((height != null && !height.isEmpty()) ? Integer.parseInt(height) : size.getHeight())
                    .dpi((dpi != null && !dpi.isEmpty()) ? Integer.parseInt(dpi) : 96)
                    .quality((quality != null && !quality.isEmpty()) ? Float.parseFloat(quality) : 1.0f)
                    .outputFormat(format);

            serviceResponse = new RasterToRaster(builder).convert();

//            System.out.println("1 serviceResponse:" + serviceResponse);
        } catch (Exception e) {
            serviceResponse = "{\"status\":false,\"msg\":\"" + e.getMessage() + "\"}";
        }
//        System.out.println("2. serviceResponse:" + this.prepareResult(serviceResponse));
        return this.prepareResult(serviceResponse);
    }

    public String rasterToSvg(
            String input,
            String output,
            String scale,//Double
            String colorReduction
    ) {
        String serviceResponse = null;
        try {
            input = sanitize(input);
            output = sanitize(output);
            scale = sanitize(scale);
            colorReduction = sanitize(colorReduction);
            if (input == null || input.isEmpty()) {
                throw new IllegalArgumentException("Input file is required");
            }
            if (output == null || output.isEmpty()) {
                throw new IllegalArgumentException("Output file path is required");
            }
            serviceResponse = new RasterToSvg(input, output,
                    (scale != null && !scale.isEmpty()) ? Double.parseDouble(scale + "") : 1.0,
                    (colorReduction != null && !colorReduction.isEmpty()) ? Integer.parseInt(colorReduction) : 64
            ).convertToSVG();
        } catch (Exception e) {
            serviceResponse = "{\"status\":false,\"msg\":\"" + e.getMessage() + "\"}";
        }
        return this.prepareResult(serviceResponse);
    }

    public String svgToRaster(
            String input,
            String output,
            String format,
            String dpi,//Integer
            String width,//Integer
            String height,//Integer
            String scale//Float
    ) {
        String serviceResponse = null;
        try {

            input = sanitize(input);
            output = sanitize(output);
            format = sanitize(format);
            dpi = sanitize(dpi);
            width = sanitize(width);
            height = sanitize(height);
            scale = sanitize(scale);

            if (input == null || input.isEmpty()) {
                throw new IllegalArgumentException("Input file is required");
            }
            if (format == null || format.isEmpty()) {
                throw new IllegalArgumentException("Output format is required");
            }
            Dimensions size = this.getDefaultSVGDimensions(input);

            if (size != null && size.getHeight() > 0 && size.getHeight() > 0) {
                if (width != null && !width.isEmpty() && (height == null || height.isEmpty())) {
                    //then find height
                    height = (Integer.parseInt(width) * size.getHeight()) / (size.getWidth()) + "";
                } else if (height != null && !height.isEmpty() && (width == null || width.isEmpty())) {
                    //then find width
                    width = (Integer.parseInt(height) * size.getWidth()) / (size.getHeight()) + "";
                }
            }

            SvgToRaster svgToRaster;
            boolean isMultiFormat = this.isMultipleFormats(format);
            String outFileName = this.getFileNameWithoutExtension(input);
            if (isMultiFormat) {
                StringBuilder results = new StringBuilder();
                String[] formatArray = this.extractImageFormats(format);
                if (output == null || output.isEmpty()) {
                    output = this.getParentDirectoryPath(input);
                }
                for (String ext : formatArray) {
                    if (ext != null && !ext.isEmpty()) {
                        ext = ext.trim();
                    } else {
                        ext = "png";
                    }
                    results.append(new SvgToRaster(
                            input,
                            output + "/" + outFileName + "." + ext,
                            ext,
                            ((dpi != null && !dpi.isEmpty()) ? Integer.parseInt(dpi) : 96),
                            ((width != null && !width.isEmpty()) ? Integer.parseInt(width) : size.getWidth()),
                            ((height != null && !height.isEmpty()) ? Integer.parseInt(height) : size.getHeight()),
                            (scale != null && !scale.isEmpty()) ? Float.parseFloat(scale + "") : 1.0f
                    ).convert());
                }
                serviceResponse = "{\"status\":true,\"msg\":\"" + results.toString() + "\"}";
            } else {
                if (format != null && !format.isEmpty()) {
                    format = format.trim();
                } else {
                    format = "png";
                }
                if (output == null || output.isEmpty()) {
                    output = getFilePathWithoutExtension(input) + "." + format;
                }

                // single format
                serviceResponse = new SvgToRaster(
                        input,
                        output,
                        //                        output + "/" + outFileName + "." + format,
                        format,
                        ((dpi != null && !dpi.isEmpty()) ? Integer.parseInt(dpi) : 96),
                        ((width != null && !width.isEmpty()) ? Integer.parseInt(width) : size.getWidth()),
                        ((height != null && !height.isEmpty()) ? Integer.parseInt(height) : size.getHeight()),
                        (scale != null && !scale.isEmpty()) ? Float.parseFloat(scale + "") : 1.0f
                ).convert();
            }

        } catch (Exception e) {
            serviceResponse = "{\"status\":false,\"msg\":\"" + e.getMessage() + "\"}";
        }
        return this.prepareResult(serviceResponse);
    }

    public String svgToVector(String input, String output, String format) {
        String serviceResponse = null;
        try {

            input = sanitize(input);
            output = sanitize(output);
            format = sanitize(format);

            if (input == null || input.isEmpty()) {
                throw new IllegalArgumentException("Input file is required");
            }
            if (output == null || output.isEmpty()) {
                throw new IllegalArgumentException("Output file path is required");
            }
            if (format == null || format.isEmpty()) {
                throw new IllegalArgumentException("Output format is required");
            }

            boolean isMultiFormat = this.isMultipleFormats(format);
            SvgToVector svgToVector;

            if (isMultiFormat) {
                StringBuilder results = new StringBuilder();
                String outFileName = this.getFileNameWithoutExtension(input);
                if (output == null || output.isEmpty()) {
                    output = this.getParentDirectoryPath(input);
                }
                // multiple formats
                String[] formatArray = this.extractImageFormats(format);
                for (String ext : formatArray) {
                    if (ext != null && !ext.isEmpty()) {
                        ext = ext.trim();
                    } else {
                        ext = "eps";
                    }

                    results.append(new SvgToVector(input, output + "/" + outFileName + "." + ext, ext).convert());
                }
                serviceResponse = "{\"status\":true,\"msg\":\"" + results.toString() + "\"}";
            } else {
                if (format != null && !format.isEmpty()) {
                    format = format.trim();
                } else {
                    format = "eps";
                }
                if (output == null || output.isEmpty()) {
                    output = getFilePathWithoutExtension(input) + "." + format;
                }
                // single format
//                    serviceResponse = new SvgToVector(input, output + "/" + outFileName + "." + format, format).convert();
//                System.out.println("✅ inputSVGPath:" + input);
//                System.out.println("✅ outputVectorPath:" + output);
//                System.out.println("✅ format:" + format);
                serviceResponse = new SvgToVector(input, output, format).convert();
            }

        } catch (Exception e) {
            System.out.println(e.getStackTrace());
            serviceResponse = "{\"status\":false,\"msg\":\"" + e.getMessage() + "\"}";
        }
        return this.prepareResult(serviceResponse);
    }

    public String rasterToVector(
            String input,
            String output,
            String format,
            String scale,
            String colorReduction//Integer
    ) {
        String serviceResponse = null;
        try {
            input = sanitize(input);
            output = sanitize(output);
            format = sanitize(format);
            colorReduction = sanitize(colorReduction);
            scale = sanitize(scale);

            if (input == null || input.isEmpty()) {
                throw new IllegalArgumentException("Input file is required");
            }

            if (format == null || format.isEmpty()) {
                format = "svg";
            }

            Dimensions size = this.getImageDimensions(input);
            RasterToVector rasterToVector;
            boolean isMultiFormat = this.isMultipleFormats(format);
            if (GlobalProperties.isDebug) {
                System.out.println("isMultiFormat:" + isMultiFormat);
            }

            String outFileName = this.getFileNameWithoutExtension(input);
            if (GlobalProperties.isDebug) {
                System.out.println("outFileName:" + outFileName);
            }
            if (GlobalProperties.isDebug) {
                System.out.println("output directory:" + output);
            }
            Double scaleFact = 1.0;
            if (scale != null && !scale.isEmpty()) {
                scaleFact = Double.parseDouble(scale + "");
            }
            int colorRed = 64;

            if (colorReduction != null && !colorReduction.isEmpty()) {
                colorRed = Integer.parseInt(colorReduction + "");
            }
            if (isMultiFormat) {
                StringBuilder results = new StringBuilder();
                String[] formatArray = this.extractImageFormats(format);
                if (output == null || output.isEmpty()) {
                    output = this.getParentDirectoryPath(input);
                }
                if (GlobalProperties.isDebug) {
                    System.out.println("Formats: " + Arrays.toString(formatArray));
                }

                for (String fmt : formatArray) {
                    if (fmt != null && !fmt.isEmpty()) {
                        fmt = fmt.trim();
                    } else {
                        fmt = "svg";
                    }
                    if (GlobalProperties.isDebug) {
                        System.out.println("formatStr:" + fmt.trim());
                    }

                    switch (fmt) {
                        case "svg":
                            results.append(new RasterToVector(input, output + "/" + outFileName + "." + fmt, scaleFact, colorRed).convertToSVG());
                            break;
                        case "eps":
                            results.append(new RasterToVector(input, output + "/" + outFileName + "." + fmt, scaleFact, colorRed).convertToEPS());
                            break;
                        case "tiff":
                            results.append(new RasterToVector(input, output + "/" + outFileName + "." + fmt, scaleFact, colorRed).convertToTIFF());
                            break;
                        case "ai":
                            results.append(new RasterToVector(input, output + "/" + outFileName + "." + fmt, scaleFact, colorRed).convertToAI());
                            break;
                    }
                }
                serviceResponse = results.toString();
            } else {
                if (format != null && !format.isEmpty()) {
                    format = format.trim();
                } else {
                    format = "svg";
                }
                if (output == null || output.isEmpty()) {
                    output = getFilePathWithoutExtension(input) + "." + format;
                }

                if (GlobalProperties.isDebug) {
                    System.out.println("format:" + format.trim());
                }
                // single format
                switch (format) {
                    case "svg":
                        serviceResponse = new RasterToVector(input, output, scaleFact, colorRed).convertToSVG();
                        break;
                    case "eps":
                        serviceResponse = new RasterToVector(input, output, scaleFact, colorRed).convertToEPS();
                        break;
                    case "tiff":
                        serviceResponse = new RasterToVector(input, output, scaleFact, colorRed).convertToTIFF();
                        break;
                    case "ai":
                        serviceResponse = new RasterToVector(input, output, scaleFact, colorRed).convertToAI();
                        break;
                }
            }

        } catch (Exception e) {
            serviceResponse = "{\"status\":false,\"msg\":\"" + e.getMessage() + "\"}";
        }
        return this.prepareResult(serviceResponse);
    }

    public String inkscapeToImage(
            String input,
            String output,
            String format,
            String dpi,
            String width,
            String height,
            String exportArea,
            String exportBackground,
            String exportBackgroundOpacity,
            String exportPlainSvg,
            String exportMargin,
            String exportId,
            String exportIdOnly,
            String isDebug,
            String additionalOptions
    ) {
        String serviceResponse = null;
        try {

            input = sanitize(input);
            output = sanitize(output);
            format = sanitize(format);
            dpi = sanitize(dpi);
            width = sanitize(width);
            height = sanitize(height);
            exportArea = sanitize(exportArea);
            exportBackground = sanitize(exportBackground);
            exportBackgroundOpacity = sanitize(exportBackgroundOpacity);
            exportPlainSvg = sanitize(exportPlainSvg);
            exportMargin = sanitize(exportMargin);
            exportId = sanitize(exportId);
            exportIdOnly = sanitize(exportIdOnly);
            isDebug = sanitize(isDebug);
            additionalOptions = sanitize(additionalOptions);

            if (input == null || input.isEmpty()) {
                throw new IllegalArgumentException("Input file is required");
            }

            if (format == null || format.isEmpty()) {
                throw new IllegalArgumentException("Output format is required");
            }
            if ((isDebug != null && !isDebug.isEmpty() && isDebug.equalsIgnoreCase("true"))) {
                GlobalProperties.isDebug = true;
            } else {
                GlobalProperties.isDebug = false;
            }

            Dimensions size = this.getDefaultSVGDimensions(input);

            if (size != null && size.getHeight() > 0 && size.getHeight() > 0) {
                if (width != null && !width.isEmpty() && (height == null || height.isEmpty())) {
                    //then find height
                    height = (Integer.parseInt(width) * size.getHeight()) / (size.getWidth()) + "";
                } else if (height != null && !height.isEmpty() && (width == null || width.isEmpty())) {
                    //then find width
                    width = (Integer.parseInt(height) * size.getWidth()) / (size.getHeight()) + "";
                }
            }

            boolean isMultiFormat = this.isMultipleFormats(format);
            String outFileName = this.getFileNameWithoutExtension(input);
            InkscapeCommandCreator creator = new InkscapeCommandCreator();

            if (isMultiFormat) {
                List<InkscapeOptions> tasks = new ArrayList<>();
                // multiple formats
                String[] formatArray = this.extractImageFormats(format);
                if (output == null || output.isEmpty()) {
                    output = this.getParentDirectoryPath(input);
                }
                for (String ext : formatArray) {
                    if (ext != null && !ext.isEmpty()) {
                        ext = ext.trim();
                    } else {
                        ext = "png";
                    }

                    InkscapeOptions options = new InkscapeOptions();
                    options.setInputFilePath(input);
                    options.setOutputFilePath(output + "/" + outFileName + "." + ext);
                    options.setExportType(ext);

                    options.setDpi((dpi != null && !dpi.isEmpty()) ? Integer.parseInt(dpi) : 96);
                    options.setWidth((width != null && !width.isEmpty()) ? Integer.parseInt(width) : size.getWidth());
                    options.setHeight((height != null && !height.isEmpty()) ? Integer.parseInt(height) : size.getHeight());

                    if (exportArea != null && !exportArea.isEmpty()) {
                        options.setArea(exportArea);
                    }
                    if (exportBackground != null && !exportBackground.isEmpty()) {
                        options.setBackground(exportBackground);
                    }

                    if (exportBackgroundOpacity != null && !exportBackgroundOpacity.isEmpty()) {
                        options.setBackgroundOpacity(Double.parseDouble(exportBackgroundOpacity));
                    }
                    if (exportPlainSvg != null && !exportPlainSvg.isEmpty()) {
                        options.setExportPlainSvg(exportPlainSvg.equalsIgnoreCase("true") ? true : false);
                    }
                    if (exportMargin != null && !exportMargin.isEmpty()) {
                        options.setMargin(Integer.parseInt(exportMargin));
                    }
                    if (exportId != null && !exportId.isEmpty()) {
                        options.setExportId(exportId);
                    }
                    if (exportIdOnly != null && !exportIdOnly.isEmpty()) {
                        options.setExportIdOnly(exportIdOnly.equalsIgnoreCase("true") ? true : false);
                    }

                    if (additionalOptions != null && !additionalOptions.isEmpty()) {
                        List<String> optionsList = Arrays.stream(additionalOptions.split(",")).map(String::trim).collect(Collectors.toList());
                        options.setAdditionalOptions(optionsList);
                    }

                    tasks.add(options);
                }
                List<Future<Boolean>> futures = new ArrayList<>();
                for (InkscapeOptions options : tasks) {

                    InkscapeCommand command = creator.createInkscapeCommand(options);
                    futures.add(creator.executeCommand(command)); // Submitting tasks without waiting
//                    System.out.println("=================================>command started");
                }
                StringBuilder results = new StringBuilder();
                // Wait for all tasks to complete
                try {
                    for (int i = 0; i < futures.size(); i++) {
                        boolean isCompleted = futures.get(i).get(); // Blocks only when retrieving status\
                        results.append((i + 1) + ". Execution status: " + (isCompleted ? "Success" : "Failed"));
                    }
                } catch (Exception ee) {
                    ee.printStackTrace();
                }
                serviceResponse = "{\"status\":true,\"msg\":\"" + results.toString() + "\"}";
            } else {
                if (format != null && !format.isEmpty()) {
                    format = format.trim();
                } else {
                    format = "png";
                }
                if (output == null || output.isEmpty()) {
                    output = getFilePathWithoutExtension(input) + "." + format;
                }

                InkscapeOptions options = new InkscapeOptions();
                options.setInputFilePath(input);
//                options.setOutputFilePath(output + "/" + outFileName + "." + format);
                options.setOutputFilePath(output);
                options.setExportType(format);
                options.setDpi((dpi != null && !dpi.isEmpty()) ? Integer.parseInt(dpi) : 96);
                options.setWidth((width != null && !width.isEmpty()) ? Integer.parseInt(width) : size.getWidth());
                options.setHeight((height != null && !height.isEmpty()) ? Integer.parseInt(height) : size.getHeight());

                if (exportArea != null && !exportArea.isEmpty()) {
                    options.setArea(exportArea);
                }
                if (exportBackground != null && !exportBackground.isEmpty()) {
                    options.setBackground(exportBackground);
                }

                if (exportBackgroundOpacity != null && !exportBackgroundOpacity.isEmpty()) {
                    options.setBackgroundOpacity(Double.parseDouble(exportBackgroundOpacity));
                }
                if (exportPlainSvg != null && !exportPlainSvg.isEmpty()) {
                    options.setExportPlainSvg(exportPlainSvg.equalsIgnoreCase("true") ? true : false);
                }
                if (exportMargin != null && !exportMargin.isEmpty()) {
                    options.setMargin(Integer.parseInt(exportMargin));
                }
                if (exportId != null && !exportId.isEmpty()) {
                    options.setExportId(exportId);
                }
                if (exportIdOnly != null && !exportIdOnly.isEmpty()) {
                    options.setExportIdOnly(exportIdOnly.equalsIgnoreCase("true") ? true : false);
                }

                if (additionalOptions != null && !additionalOptions.isEmpty()) {
                    List<String> optionsList = Arrays.stream(additionalOptions.split(",")).map(String::trim).collect(Collectors.toList());
                    options.setAdditionalOptions(optionsList);
                }
                InkscapeCommand command = creator.createInkscapeCommand(options);
                Future<Boolean> future = creator.executeCommand(command);

                if (future.get()) {
                    serviceResponse = "{\"status\":true,\"msg\":\"File(s) have been created successfully\"}";
                } else {
                    serviceResponse = "{\"status\":false,\"msg\":\"Some thing went wrong, kindly debug the issue\"}";
                }

            }
        } catch (Exception e) {
            serviceResponse = "{\"status\":false,\"msg\":\"" + e.getMessage() + "\"}";
        }
        return this.prepareResult(serviceResponse);
    }

    public static void main(String[] args) {
        try {

           

            // Convert to EPS
            new Eigc().rasterToVector("/home/saleem/Pictures/spiderman.png", "/home/saleem/Pictures/rtv", "svg, eps, ai, tiff","0.5","64");

//            // Convert to AI (Adobe Illustrator)
//            new Eigc().svgToVector(inputSVG, "/home/saleem/Pictures/stv/color_logo.ai", "ai");
//
//            // Convert to TIFF (Vector)
//            new Eigc().svgToVector(inputSVG, "/home/saleem/Pictures/stv/color_logo.tiff", "tiff");
//
//            // Convert to PDF (Vector)
//            new Eigc().svgToVector(inputSVG, "/home/saleem/Pictures/stv/color_logo.pdf", "pdf");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
