/*
 * The MIT License
 * Copyright (c) 2024-2025 Elite India
 *
 * Author: Saleem Ahmad
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.elite.india.sa;

/**
 *
 * @author saleem
 */
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;

/**
 * The RasterToSvgEdges class provides functionality to convert a raster image to an SVG representation
 * by detecting edges in the image and generating corresponding SVG paths.
 * <p>
 * The conversion process involves the following steps:
 * <ul>
 *   <li>Converting the image to grayscale.</li>
 *   <li>Applying edge detection using a simple Sobel filter.</li>
 *   <li>Generating SVG paths from the detected edges.</li>
 *   <li>Saving the generated SVG data to a file.</li>
 * </ul>
 * <p>
 * Example usage:
 * <pre>
 * {@code
 * String inputImage = "/path/to/input/image.png";
 * String outputSVG = "/path/to/output/image.svg";
 * 
 * RasterToSvgEdges converter = new RasterToSvgEdges(inputImage, outputSVG);
 * converter.convertToSVG();
 * }
 * </pre>
 * <p>
 * Note: This class requires the Java AWT and ImageIO libraries for image processing.
 * 
 * @see java.awt.image.BufferedImage
 * @see javax.imageio.ImageIO
 */
public class RasterToSvgEdges {
    private BufferedImage image;
    private String outputFilePath;

    /**
     * Constructs a RasterToSVGEdges object with the specified input image path and output file path.
     *
     * @param inputImagePath the path to the input image file
     * @param outputFilePath the path to the output SVG file
     * @throws IOException if an error occurs during reading the input image file
     */
    public RasterToSvgEdges(String inputImagePath, String outputFilePath) throws IOException {
        this.image = ImageIO.read(new File(inputImagePath));
        this.outputFilePath = outputFilePath;
    }

    /**
     * Converts the given image to an SVG representation.
     * <p>
     * This method performs the following steps:
     * <ul>
     *   <li>Converts the image to grayscale.</li>
     *   <li>Applies edge detection using a simple Sobel filter.</li>
     *   <li>Generates SVG paths from the detected edges.</li>
     *   <li>Saves the generated SVG data to a file.</li>
     * </ul>
     * 
     * @throws Exception if an error occurs during the conversion process.
     */
    public void convertToSVG() throws Exception {
        // Convert image to grayscale
        BufferedImage grayImage = toGrayscale(image);
        
        // Apply edge detection (Simple Sobel filter)
        boolean[][] edgeMatrix = detectEdges(grayImage);
        
        // Convert edges to SVG paths
        String svgData = generateSVG(edgeMatrix);
        
        // Save to SVG file
        saveSVG(svgData);
    }

    /**
     * Converts the given BufferedImage to a grayscale image.
     *
     * @param img the original BufferedImage to be converted
     * @return a new BufferedImage that is a grayscale version of the original image
     */
    private BufferedImage toGrayscale(BufferedImage img) {
        BufferedImage gray = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
        Graphics g = gray.getGraphics();
        g.drawImage(img, 0, 0, null);
        g.dispose();
        return gray;
    }

    /**
     * Detects edges in a given BufferedImage using a simple Sobel filter.
     *
     * @param img the BufferedImage to detect edges in
     * @return a 2D boolean array where true indicates the presence of an edge
     */
    private boolean[][] detectEdges(BufferedImage img) {
        int width = img.getWidth();
        int height = img.getHeight();
        boolean[][] edges = new boolean[width][height];

        // Simple Sobel filter
        int[][] sobelX = {{-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1}};
        int[][] sobelY = {{1, 2, 1}, {0, 0, 0}, {-1, -2, -1}};

        for (int x = 1; x < width - 1; x++) {
            for (int y = 1; y < height - 1; y++) {
                int gx = 0, gy = 0;

                for (int i = -1; i <= 1; i++) {
                    for (int j = -1; j <= 1; j++) {
                        int pixel = new Color(img.getRGB(x + i, y + j)).getRed();
                        gx += pixel * sobelX[i + 1][j + 1];
                        gy += pixel * sobelY[i + 1][j + 1];
                    }
                }

                int edgeStrength = (int) Math.sqrt(gx * gx + gy * gy);
                edges[x][y] = edgeStrength > 100; // Threshold
            }
        }
        return edges;
    }

    /**
     * Generates an SVG representation of the given edges.
     *
     * @param edges A 2D boolean array where true indicates the presence of an edge.
     * @return A string containing the SVG markup.
     */
    private String generateSVG(boolean[][] edges) {
        int width = edges.length, height = edges[0].length;
        StringBuilder svg = new StringBuilder();
        svg.append("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 " + width + " " + height + "'>\n");
        svg.append("<g stroke='black' fill='none'>\n");

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                if (edges[x][y]) {
                    svg.append("<path d='M" + x + "," + y + " L" + (x + 1) + "," + (y + 1) + "' stroke-width='1' />\n");
                }
            }
        }

        svg.append("</g>\n</svg>");
        return svg.toString();
    }

    /**
     * Saves the provided SVG data to a file specified by the outputFilePath.
     *
     * @param svgData the SVG data to be saved as a String
     * @throws IOException if an I/O error occurs while writing the file
     */
    private void saveSVG(String svgData) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
            writer.write(svgData);
        }
        System.out.println("SVG saved: " + outputFilePath);
    }

    public static void main(String[] args) {
        try {
            

            String inputImage = "/home/saleem/Pictures/spiderman.png";
            String outputSVG = "/home/saleem/Pictures/spiderman2.svg";

            RasterToSvgEdges converter = new RasterToSvgEdges(inputImage, outputSVG);
            converter.convertToSVG();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

