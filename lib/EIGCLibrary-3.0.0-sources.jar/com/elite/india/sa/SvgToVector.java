/*
 * The MIT License
 * Copyright (c) 2024-2025 Elite India
 *
 * Author: Saleem Ahmad
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.elite.india.sa;

import org.apache.batik.transcoder.Transcoder;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.fop.svg.PDFTranscoder;
import org.apache.fop.render.ps.PSTranscoder;
import org.apache.batik.transcoder.image.TIFFTranscoder;
import java.io.*;

import org.apache.fop.render.ps.EPSTranscoder;

/**
 * The VectorToVector class provides functionality to convert SVG files to
 * various vector formats. Supported formats include EPS, AI (Adobe
 * Illustrator), TIFF, and PDF.
 *
 * <p>
 * Usage example:
 * <pre>
 * {@code
 * SvgToVector converter = new SvgToVector("/path/to/input.svg", "/path/to/output.eps", "eps");
 * converter.convert();
 * }
 * </pre>
 * </p>
 *
 * <p>
 * Supported formats:
 * <ul>
 * <li>eps - Encapsulated PostScript</li>
 * <li>ai - Adobe Illustrator</li>
 * <li>tiff - Tagged Image File Format</li>
 * <li>pdf - Portable Document Format</li>
 * </ul>
 * </p>
 *
 * <p>
 * Example usage in the main method:
 * <pre>
 * {@code
 * public static void main(String[] args) {
 * try {
 * String inputSVG = "/path/to/input.svg";
 *
 * // Convert to EPS
 * new SvgToVector(inputSVG, "/path/to/output.eps", "eps").convert();
 *
 * // Convert to AI (Adobe Illustrator)
 * new SvgToVector(inputSVG, "/path/to/output.ai", "ai").convert();
 *
 * // Convert to TIFF (Vector)
 * new SvgToVector(inputSVG, "/path/to/output.tiff", "tiff").convert();
 *
 * // Convert to PDF (Vector)
 * new SvgToVector(inputSVG, "/path/to/output.pdf", "pdf").convert();
 *
 * } catch (Exception e) {
 * e.printStackTrace();
 * }
 * }
 * }
 * </pre>
 * </p>
 *
 * <p>
 * Note: The conversion process relies on the Apache Batik library for
 * transcoding SVG files. Ensure that the necessary dependencies are included in
 * your project.</p>
 *
 * @see org.apache.batik.transcoder.Transcoder
 * @see org.apache.batik.transcoder.TranscoderInput
 * @see org.apache.batik.transcoder.TranscoderOutput
 */
public class SvgToVector {

    private String inputSVGPath;
    private String outputVectorPath;
    private String format;

    /**
     * Constructs a VectorToVector object with the specified input SVG path,
     * output vector path, and format.
     *
     * @param inputSVGPath the path to the input SVG file
     * @param outputVectorPath the path to the output vector file
     * @param format the format of the output vector file, converted to
     * lowercase
     */
    public SvgToVector(String inputSVGPath, String outputVectorPath, String format) {
        this.inputSVGPath = inputSVGPath;
        this.outputVectorPath = outputVectorPath;
        this.format = format.toLowerCase();
        
        // ✅ Redirect Java Console Output to Node.js Console
        PrintStream consoleOut = System.out;
        PrintStream consoleErr = System.err;

        System.setOut(new PrintStream(System.out) {
            public void println(String s) {
                super.println("[GTGS-LOG] " + s);
            }
        });

        System.setErr(new PrintStream(System.err) {
            public void println(String s) {
                super.println("[CORE-ERROR] " + s);
            }
        });

        System.out.println("✅ SvgToVector Class Initialized!");
//        System.out.println("✅ inputSVGPath:"+ this.inputSVGPath);
//        System.out.println("✅ outputVectorPath:"+ this.outputVectorPath);
//        System.out.println("✅ format:"+ this.format);
    }

    /**
     * Converts an SVG file to a specified vector format.
     *
     * @throws Exception if an error occurs during the conversion process.
     * @throws IllegalArgumentException if the specified vector format is
     * unsupported.
     */
    public String convert() throws Exception {
        String response = "";
        try {
            Transcoder transcoder;

            switch (format) {
                case "eps":
                    transcoder = new EPSTranscoder();
                    break;
                case "ai":
                    transcoder = new PSTranscoder(); // Adobe Illustrator (AI) is based on PostScript
                    break;
                case "tiff":
                    transcoder = new TIFFTranscoder();
                    break;
                case "pdf":
                    transcoder = new PDFTranscoder();
                    break;
                default:
                    throw new IllegalArgumentException("Unsupported vector format: " + format);
            }

            try (FileInputStream svgFile = new FileInputStream(inputSVGPath); FileOutputStream outputFile = new FileOutputStream(outputVectorPath)) {
                TranscoderInput input = new TranscoderInput(svgFile);
                TranscoderOutput output = new TranscoderOutput(outputFile);
                transcoder.transcode(input, output);
                System.out.println("Converted file saved: " + outputVectorPath);
            }
            response = "{\"status\":true,\"msg\":\"Image has been created successfully\"}";
        } catch (Exception e) {
            System.out.println(e.getStackTrace());
            response = "{\"status\":false,\"msg\":\"" + e.getMessage() + "\"}";
        }
        return response;
    }

    public static void main(String[] args) {
        try {
            String inputSVG = "/home/saleem/Pictures/Back_8.svg";

            // Convert to EPS
            new SvgToVector(inputSVG, "/home/saleem/Pictures/stv/color_logo.eps", "eps").convert();

            // Convert to AI (Adobe Illustrator)
            new SvgToVector(inputSVG, "/home/saleem/Pictures/stv/color_logo.ai", "ai").convert();

            // Convert to TIFF (Vector)
            new SvgToVector(inputSVG, "/home/saleem/Pictures/stv/color_logo.tiff", "tiff").convert();

            // Convert to PDF (Vector)
            new SvgToVector(inputSVG, "/home/saleem/Pictures/stv/color_logo.pdf", "pdf").convert();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
