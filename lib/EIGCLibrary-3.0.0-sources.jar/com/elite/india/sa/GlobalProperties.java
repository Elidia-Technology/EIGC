/*
 * The MIT License
 * Copyright (c) 2024-2025 Elite India
 *
 * Author: Saleem Ahmad
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.elite.india.sa;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author saleem
 */
public class GlobalProperties {
    public static boolean isDebug=false;    
    public static String inkscapeVersion="new";
    public static String getInkscapeVersion() {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder("inkscape", "--version");
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String output = reader.readLine(); // Read first line (e.g., "Inkscape 1.2.1 (9c6d41e, 2022-07-14)")

            process.waitFor(); // Wait for process to finish

            if (output != null && output.startsWith("Inkscape")) {
                String version = output.split(" ")[1]; // Extract version number
                return version;
            }
        } catch (Exception e) {
            return null; // Inkscape is not installed or command failed
        }
        return null;
    }
}
