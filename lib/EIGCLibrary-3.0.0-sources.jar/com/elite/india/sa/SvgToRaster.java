/*
 * The MIT License
 * Copyright (c) 2024-2025 Elite India
 *
 * Author: Saleem Ahmad
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.elite.india.sa;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import org.apache.batik.transcoder.image.*;
import org.apache.batik.transcoder.Transcoder;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.fop.svg.PDFTranscoder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.util.UUID;
import javax.imageio.ImageIO;

/**
 * The VectorToRaster class provides functionality to convert SVG files to
 * various raster and vector formats. Supported formats include PNG, JPG, GIF,
 * BMP, and PDF.
 *
 * <p>
 * Usage example:</p>
 * <pre>
 * {@code
 * String inputSVG = "/path/to/input.svg";
 * float dpi = 300;
 * Integer width = null; // Null means use default SVG size
 * Integer height = null;
 * float scaleFactor = 1.0f;
 *
 * // Convert to PNG
 * new SvgToRaster(inputSVG, "/path/to/output.png", "png", dpi, width, height, scaleFactor).convert();
 *
 * // Convert to JPG
 * new SvgToRaster(inputSVG, "/path/to/output.jpg", "jpg", dpi, width, height, scaleFactor).convert();
 *
 * // Convert to GIF
 * new SvgToRaster(inputSVG, "/path/to/output.gif", "gif", dpi, width, height, scaleFactor).convert();
 *
 * // Convert to BMP
 * new SvgToRaster(inputSVG, "/path/to/output.bmp", "bmp", dpi, width, height, scaleFactor).convert();
 *
 * // Convert to PDF (Scalable Vector)
 * new SvgToRaster(inputSVG, "/path/to/output.pdf", "pdf", dpi, width, height, scaleFactor).convert();
 * }
 * </pre>
 *
 * <p>
 * Supported formats:</p>
 * <ul>
 * <li>png - Portable Network Graphics</li>
 * <li>jpg/jpeg - JPEG Image</li>
 * <li>gif - Graphics Interchange Format (converted to PNG)</li>
 * <li>bmp - Bitmap (converted to TIFF)</li>
 * <li>pdf - Portable Document Format (vector output)</li>
 * </ul>
 *
 * <p>
 * The method applies width and height hints for raster images (PNG, JPG, etc.)
 * if specified. It also sets the pixel unit to millimeter conversion based on
 * the provided DPI.</p>
 *
 * <p>
 * The converted file is saved to the specified output path.</p>
 *
 * @param inputSVGPath The path to the input SVG file.
 * @param outputImagePath The path to the output image file.
 * @param format The format of the output image (e.g., "png", "jpg").
 * @param dpi The dots per inch (DPI) for the output image.
 * @param width The width of the output image in pixels.
 * @param height The height of the output image in pixels.
 * @param scaleFactor The scale factor for the output image. If null, defaults
 * to 1.0.
 *
 * @throws Exception if an error occurs during the conversion process.
 */
public class SvgToRaster {

    private String inputSVGPath;
    private String outputImagePath;
    private String format;
    private float dpi;
    private Integer width;  // Use Integer to allow null checks
    private Integer height;
    private float scaleFactor;

    /**
     * Constructs a VectorToRaster object with the specified parameters.
     *
     * @param inputSVGPath The path to the input SVG file.
     * @param outputImagePath The path to the output image file.
     * @param format The format of the output image (e.g., "png", "jpg").
     * @param dpi The dots per inch (DPI) for the output image.
     * @param width The width of the output image in pixels.
     * @param height The height of the output image in pixels.
     * @param scaleFactor The scale factor for the output image. If null,
     * defaults to 1.0.
     */
    public SvgToRaster(String inputSVGPath, String outputImagePath, String format, float dpi, Integer width, Integer height, Float scaleFactor) {
        this.inputSVGPath = inputSVGPath;
        this.outputImagePath = outputImagePath;
        this.format = format.toLowerCase();
        this.dpi = dpi;
        this.scaleFactor = (scaleFactor != null) ? scaleFactor : 1.0f; // Default scaleFactor = 1.0

        // Retrieve dimensions from the SVG file
        Dimensions dimensions = getSvgDimensions(this.inputSVGPath);

        // Ensure valid defaults (Fallback if parsing fails)
        int defaultWidth = (dimensions.getWidth() > 0) ? dimensions.getWidth() : 800;
        int defaultHeight = (dimensions.getHeight() > 0) ? dimensions.getHeight() : 600;

        // Determine the actual width and height
        if ((width == null || width <= 0) && (height == null || height <= 0)) {
            // Both are null → Use default SVG dimensions
            this.width = defaultWidth;
            this.height = defaultHeight;
        } else if ((width == null || width <= 0) && height != null && height > 0) {
            // Width is missing → Scale based on height
            this.width = (int) (defaultWidth * ((double) height / defaultHeight));
            this.height = height;
        } else if ((height == null || height <= 0) && width != null && width > 0) {
            // Height is missing → Scale based on width
            this.height = (int) (defaultHeight * ((double) width / defaultWidth));
            this.width = width;
        } else {
            // Both width & height are provided → Use as-is
            this.width = width;
            this.height = height;
        }

        // ✅ Redirect Java Console Output to Node.js Console
        PrintStream consoleOut = System.out;
        PrintStream consoleErr = System.err;

        System.setOut(new PrintStream(System.out) {
            public void println(String s) {
                super.println("[GTGS-LOG] " + s);
            }
        });

        System.setErr(new PrintStream(System.err) {
            public void println(String s) {
                super.println("[CORE-ERROR] " + s);
            }
        });

        System.out.println("✅ SvgToRaster Class Initialized!");
    }

    /**
     * Reads SVG file to extract width and height. If missing, extracts from
     * viewBox.
     *
     * @return int[] {width, height}
     */
    private Dimensions getSvgDimensions(String svgFilePath) {
        int defaultWidth = 800;
        int defaultHeight = 600;
        int width = defaultWidth;
        int height = defaultHeight;

        try {
            File file = new File(svgFilePath);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(file);
            Element svgElement = doc.getDocumentElement();

            // Extract width and height attributes
            String widthAttr = svgElement.getAttribute("width");
            String heightAttr = svgElement.getAttribute("height");

            boolean useViewBox = false;

            if (!widthAttr.isEmpty() && !heightAttr.isEmpty()) {
                if (widthAttr.contains("%") || heightAttr.contains("%")) {
                    // If width or height is in %, ignore it
                    useViewBox = true;
                } else {
                    width = convertToPixels(widthAttr);
                    height = convertToPixels(heightAttr);
                }
            } else {
                useViewBox = true;
            }

            // Check viewBox attribute as fallback
            if (useViewBox) {
                String viewBox = svgElement.getAttribute("viewBox");
                if (!viewBox.isEmpty()) {
                    String[] values = viewBox.split("\\s+");
                    if (values.length == 4) {
                        width = (int) Float.parseFloat(values[2]);
                        height = (int) Float.parseFloat(values[3]);
                    }
                }
            }

            // Ensure valid dimensions
            if (width <= 0) {
                width = defaultWidth;
            }
            if (height <= 0) {
                height = defaultHeight;
            }

        } catch (Exception e) {
            System.out.println("Error parsing SVG: " + e.getMessage());
        }

        return new Dimensions(width, height);
    }

    /**
     * Function to convert values into pixels
     *
     * @param value
     * @return
     */
    private int convertToPixels(String value) {
        if (value == null || value.isEmpty()) {
            return 0;
        }

        value = value.trim().toLowerCase();
        double pixels = 0;

        try {
            if (value.endsWith("in")) {  // Inches → Pixels
                pixels = Double.parseDouble(value.replace("in", "").trim()) * 96;
            } else if (value.endsWith("cm")) {  // Centimeters → Pixels
                pixels = Double.parseDouble(value.replace("cm", "").trim()) * 37.7952755906;
            } else if (value.endsWith("mm")) {  // Millimeters → Pixels
                pixels = Double.parseDouble(value.replace("mm", "").trim()) * 3.77952755906;
            } else if (value.endsWith("pt")) {  // Points → Pixels
                pixels = Double.parseDouble(value.replace("pt", "").trim()) * 1.3333;
            } else if (value.endsWith("pc")) {  // Picas → Pixels
                pixels = Double.parseDouble(value.replace("pc", "").trim()) * 16;
            } else {  // Assume it's already in pixels (numeric only)
                pixels = Double.parseDouble(value.replaceAll("[^0-9.]", ""));
            }
        } catch (NumberFormatException e) {
            System.out.println("Error converting value to pixels: " + value);
            return 0; // Return 0 to indicate failure
        }

        return (int) Math.round(pixels);
    }

    private String convertToBmp() {
        String response;
        try {
            String tempFileName = "temp_image_" + UUID.randomUUID().toString();
            File tempPngFile = File.createTempFile(tempFileName, ".png");
            PNGTranscoder pngTranscoder = new PNGTranscoder();
            float adjustedWidth = this.width * this.scaleFactor;
            float adjustedHeight = this.height * this.scaleFactor;
            if (adjustedWidth <= 0) {
                adjustedWidth = 800;  // Default width
            }
            if (adjustedHeight <= 0) {
                adjustedHeight = 600; // Default height
            }
            pngTranscoder.addTranscodingHint(PNGTranscoder.KEY_WIDTH, adjustedWidth);
            pngTranscoder.addTranscodingHint(PNGTranscoder.KEY_HEIGHT, adjustedHeight);
            pngTranscoder.addTranscodingHint(PNGTranscoder.KEY_PIXEL_UNIT_TO_MILLIMETER, 25.4f / dpi);
            TranscoderInput input = new TranscoderInput(new FileInputStream(this.inputSVGPath));
            TranscoderOutput output = new TranscoderOutput(new FileOutputStream(tempPngFile));
            pngTranscoder.transcode(input, output);
            BufferedImage bufferedImage = ImageIO.read(tempPngFile);
            ImageIO.write(bufferedImage, "bmp", new File(this.outputImagePath));
            BufferedImage newBufferedImage = new BufferedImage(bufferedImage.getWidth(), bufferedImage.getHeight(), BufferedImage.TYPE_INT_RGB);
            Graphics2D g = newBufferedImage.createGraphics();
            g.drawImage(bufferedImage, 0, 0, Color.WHITE, null);
            g.dispose();
            ImageIO.write(newBufferedImage, "bmp", new File(this.outputImagePath));
            tempPngFile.delete();
            response = "{\"status\":true,\"msg\":\"Image has been created successfully\"}";
        } catch (Exception eee) {
            response = "{\"status\":false,\"msg\":\"" + eee.getMessage() + "\"}";
        }
        return response;
    }

    /**
     * Converts an SVG file to a specified raster or vector format.
     *
     * @throws Exception if an error occurs during the conversion process.
     *
     * Supported formats:
     * <ul>
     * <li>png - Portable Network Graphics</li>
     * <li>jpg/jpeg - JPEG Image</li>
     * <li>gif - Graphics Interchange Format (converted to PNG)</li>
     * <li>bmp - Bitmap (converted to TIFF)</li>
     * <li>pdf - Portable Document Format (vector output)</li>
     * </ul>
     *
     * The method applies width and height hints for raster images (PNG, JPG,
     * etc.) if specified. It also sets the pixel unit to millimeter conversion
     * based on the provided DPI.
     *
     * The converted file is saved to the specified output path.
     */
    public String convert() throws Exception {
        String response;
        try {

            if (this.format.equals("bmp")) {
                return this.convertToBmp();
            }

            Transcoder transcoder;

            switch (this.format) {
                case "png":
                    transcoder = new PNGTranscoder();
                    break;
                case "jpg":
                case "jpeg":
                    transcoder = new JPEGTranscoder();
                    ((JPEGTranscoder) transcoder).addTranscodingHint(JPEGTranscoder.KEY_QUALITY, 0.95f);
                    break;
                case "gif":
                    transcoder = new PNGTranscoder();
                    break;
                case "pdf":
                    transcoder = new PDFTranscoder(); // Vector PDF output
                    break;
                default:
                    throw new IllegalArgumentException("Unsupported format: " + this.format);
            }

            // Only apply width & height hints for raster images (PNG, JPG, etc.)
            if (!this.format.equals("pdf")) {
//                System.out.println("1 Extracted SVG dimensions: width=" + this.width + ", height=" + this.height);
                float adjustedWidth = this.width * this.scaleFactor;
                float adjustedHeight = this.height * this.scaleFactor;
//                System.out.println("2 Extracted SVG dimensions: width=" + adjustedWidth + ", height=" + adjustedHeight);
                // Ensure values are positive and reasonable
                if (adjustedWidth <= 0) {
                    adjustedWidth = 800;  // Default width
                }
                if (adjustedHeight <= 0) {
                    adjustedHeight = 600; // Default height
                }
                transcoder.addTranscodingHint(PNGTranscoder.KEY_WIDTH, adjustedWidth);
                transcoder.addTranscodingHint(PNGTranscoder.KEY_HEIGHT, adjustedHeight);
                transcoder.addTranscodingHint(PNGTranscoder.KEY_PIXEL_UNIT_TO_MILLIMETER, 25.4f / dpi);
            }

            try (FileInputStream svgFile = new FileInputStream(this.inputSVGPath); FileOutputStream outputFile = new FileOutputStream(this.outputImagePath)) {
                TranscoderInput input = new TranscoderInput(svgFile);
                TranscoderOutput output = new TranscoderOutput(outputFile);
                transcoder.transcode(input, output);
            }
            response = "{\"status\":true,\"msg\":\"Image has been created successfully\"}";
        } catch (Exception e) {
            response = "{\"status\":false,\"msg\":\"" + e.getMessage() + "\"}";
        }
        return response;
    }

//    public static void main(String[] args) {
//        try {
//            String inputSVG = "/home/saleem/Pictures/color_logo.svg";
//            float dpi = 300;
//            Integer width = null; // Null means use default SVG size
//            Integer height = null;
//            float scaleFactor = 1.0f;
//
//            // Convert to PNG
//            new SvgToRaster(inputSVG, "/home/saleem/Pictures/str/color_logo.png", "png", dpi, 300, height, scaleFactor).convert();
//
//            // Convert to JPG
//            new SvgToRaster(inputSVG, "/home/saleem/Pictures/str/color_logo.jpg", "jpg", dpi, 500, height, scaleFactor).convert();
//
//            // Convert to GIF
//            new SvgToRaster(inputSVG, "/home/saleem/Pictures/str/color_logo.gif", "gif", dpi, 700, height, scaleFactor).convert();
//
//            // Convert to BMP
//            new SvgToRaster(inputSVG, "/home/saleem/Pictures/str/color_logo.bmp", "bmp", dpi, 100, height, scaleFactor).convert();
//
//            // Convert to PDF
//            new SvgToRaster(inputSVG, "/home/saleem/Pictures/str/color_logo.pdf", "pdf", dpi, width, height, scaleFactor).convert();
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
}
